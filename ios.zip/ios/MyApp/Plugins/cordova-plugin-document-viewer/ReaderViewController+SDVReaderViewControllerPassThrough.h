//
//  ReaderViewController+SDVReaderViewContollerPassThrough
//
//  modify ReaderViewController to enable a subclass' super call to pass through
//
//  Created by Philipp Bohnenstengel on 03.11.14.
//
//

#import "ReaderViewController.h"

@interface ReaderViewController (SDVReaderViewContollerPassThrough)

- (void)viewDidLoad;

@end

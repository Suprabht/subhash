(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet.entry.js",
		"common",
		0
	],
	"./ion-alert.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-alert.entry.js",
		"common",
		1
	],
	"./ion-app_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-app_8.entry.js",
		"common",
		2
	],
	"./ion-avatar_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-avatar_3.entry.js",
		"common",
		3
	],
	"./ion-back-button.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-back-button.entry.js",
		"common",
		4
	],
	"./ion-backdrop.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-backdrop.entry.js",
		5
	],
	"./ion-button_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-button_2.entry.js",
		"common",
		6
	],
	"./ion-card_5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-card_5.entry.js",
		"common",
		7
	],
	"./ion-checkbox.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-checkbox.entry.js",
		"common",
		8
	],
	"./ion-chip.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-chip.entry.js",
		"common",
		9
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js",
		10
	],
	"./ion-datetime_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-datetime_3.entry.js",
		"common",
		11
	],
	"./ion-fab_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-fab_3.entry.js",
		"common",
		12
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-img.entry.js",
		13
	],
	"./ion-infinite-scroll_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2.entry.js",
		14
	],
	"./ion-input.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-input.entry.js",
		"common",
		15
	],
	"./ion-item-option_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item-option_3.entry.js",
		"common",
		16
	],
	"./ion-item_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item_8.entry.js",
		"common",
		17
	],
	"./ion-loading.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-loading.entry.js",
		"common",
		18
	],
	"./ion-menu_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-menu_3.entry.js",
		"common",
		19
	],
	"./ion-modal.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-modal.entry.js",
		"common",
		20
	],
	"./ion-nav_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js",
		"common",
		21
	],
	"./ion-popover.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-popover.entry.js",
		"common",
		22
	],
	"./ion-progress-bar.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-progress-bar.entry.js",
		"common",
		23
	],
	"./ion-radio_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-radio_2.entry.js",
		"common",
		24
	],
	"./ion-range.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-range.entry.js",
		"common",
		25
	],
	"./ion-refresher_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-refresher_2.entry.js",
		"common",
		26
	],
	"./ion-reorder_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-reorder_2.entry.js",
		"common",
		27
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js",
		28
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js",
		"common",
		29
	],
	"./ion-searchbar.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-searchbar.entry.js",
		"common",
		30
	],
	"./ion-segment_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-segment_2.entry.js",
		"common",
		31
	],
	"./ion-select_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-select_3.entry.js",
		"common",
		32
	],
	"./ion-slide_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-slide_2.entry.js",
		33
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js",
		"common",
		34
	],
	"./ion-split-pane.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-split-pane.entry.js",
		35
	],
	"./ion-tab-bar_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab-bar_2.entry.js",
		"common",
		36
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js",
		"common",
		37
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-text.entry.js",
		"common",
		38
	],
	"./ion-textarea.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-textarea.entry.js",
		"common",
		39
	],
	"./ion-toast.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toast.entry.js",
		"common",
		40
	],
	"./ion-toggle.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toggle.entry.js",
		"common",
		41
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js",
		42
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/@ionic/pwa-elements/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/pwa-elements/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./pwa-action-sheet.entry.js": [
		"./node_modules/@ionic/pwa-elements/dist/esm/pwa-action-sheet.entry.js",
		43
	],
	"./pwa-camera-modal-instance.entry.js": [
		"./node_modules/@ionic/pwa-elements/dist/esm/pwa-camera-modal-instance.entry.js",
		44
	],
	"./pwa-camera-modal.entry.js": [
		"./node_modules/@ionic/pwa-elements/dist/esm/pwa-camera-modal.entry.js",
		45
	],
	"./pwa-camera.entry.js": [
		"./node_modules/@ionic/pwa-elements/dist/esm/pwa-camera.entry.js",
		46
	],
	"./pwa-toast.entry.js": [
		"./node_modules/@ionic/pwa-elements/dist/esm/pwa-toast.entry.js",
		47
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/pwa-elements/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n  <ion-menu side=\"start\" menuId=\"first\" contentId=\"main\">\n    <ion-header>\n      <ion-toolbar color=\"primary\">\n        <ion-title>\n          Welcome!\n        </ion-title>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content>\n      <ion-list>\n        <ion-menu-toggle>\n          <ion-item lines=\"none\" routerLink=\"/tabs/visitorDetailsTab\">\n            <ion-icon name=\"albums\"></ion-icon>\n              <ion-label color=\"primary\">\n                Visitors Details\n              </ion-label>\n          </ion-item>\n        </ion-menu-toggle>\n        <ion-menu-toggle>\n          <ion-item lines=\"none\" routerLink=\"/tabs/visitorListingTab\">\n            <ion-icon name=\"list-outline\"></ion-icon>\n              <ion-label color=\"primary\">\n                Visitors List\n              </ion-label>\n          </ion-item>\n        </ion-menu-toggle>\n        <ion-menu-toggle>\n          <ion-item lines=\"none\" routerLink=\"/tabs/reportsTab\">\n            <ion-icon name=\"analytics-outline\"></ion-icon>\n              <ion-label color=\"primary\">\n                Report\n              </ion-label>\n          </ion-item>\n        </ion-menu-toggle>\n        <ion-menu-toggle>\n          <ion-item lines=\"none\" routerLink=\"/changepassword\">\n            <ion-icon name=\"key-outline\"></ion-icon>\n              <ion-label color=\"primary\">\n                Change Password\n              </ion-label>\n          </ion-item>\n        </ion-menu-toggle>\n        <ion-menu-toggle>\n          <ion-item lines=\"none\" (click)=\"logout()\">\n            <ion-icon name=\"log-out-outline\"></ion-icon>\n              <ion-label color=\"primary\">\n                Logout\n              </ion-label>\n          </ion-item>\n        </ion-menu-toggle>\n      </ion-list>\n    </ion-content>\n    <ion-footer>\n      <ion-toolbar>\n        <ion-title>SDL Copyright@2020</ion-title>\n      </ion-toolbar>\n    </ion-footer>\n  </ion-menu>\n  <ion-router-outlet  id=\"main\"></ion-router-outlet>\n</ion-app>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/modals/searchuser/searchuser.page.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modals/searchuser/searchuser.page.html ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"success\">\n    <ion-title>Search RWS User</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-fab horizontal=\"end\" vertical=\"top\" slot=\"fixed\" edge>\n    <ion-fab-button color=\"danger\" (click)=\"closeModal()\">\n        <ion-icon name=\"close-circle-outline\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <ion-searchbar (ionInput)=\"filterUserData($event)\" value=\"{{this.selectedUser.displayName}}\"></ion-searchbar>\n  &nbsp;&nbsp;<ion-text color=\"success\" *ngIf=\"this.selectedUser.displayName!=''\">Selected User: {{this.selectedUser.displayName}} {{this.selectedUser.email}}</ion-text>\n  &nbsp;&nbsp;<ion-button *ngIf=\"this.selectedUser.displayName!=''\" color=\"tertiary\" type=\"submit\" (click) =\"done()\" >\n    <ion-icon name=\"save-outline\"></ion-icon>\n    &nbsp;&nbsp;Done\n  </ion-button>\n  <ion-list *ngIf=\"isEmployeeDropDownVisible\">\n    <ion-item (click)=\"selectVal(item)\" *ngFor=\"let item of usersList\">{{item.displayName}}, {{item.email}}</ion-item>\n  </ion-list>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/modals/visitor-details/visitor-details.page.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modals/visitor-details/visitor-details.page.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"success\">\n    <ion-title>Visitor Details</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-fab horizontal=\"end\" vertical=\"top\" slot=\"fixed\" edge>\n        <ion-fab-button color=\"danger\" (click)=\"closeModal()\">\n            <ion-icon name=\"close-circle-outline\"></ion-icon>\n        </ion-fab-button>\n    </ion-fab>\n    <ion-card>\n      <ion-card-header>\n        <ion-card-subtitle>#{{visitorService.selectedVisitor.visitorId}}</ion-card-subtitle>\n        <ion-card-title>{{visitorService.selectedVisitor.visitorName}}</ion-card-title>\n      </ion-card-header>\n      <ion-card-content class=\"visitorDetailCardContent\">\n          <div class=\"visitorDetailContent\">\n              <ion-chip>\n                  <ion-icon color=\"success\" name=\"mail\"></ion-icon>\n                  <ion-label><a href=\"mailto:{{visitorService.selectedVisitor.email | lowercase}}\" style=\"text-decoration: none; color:#000; cursor: pointer;\">{{visitorService.selectedVisitor.email | lowercase}}</a></ion-label>\n              </ion-chip>\n              <ion-chip>\n                  <ion-icon color=\"success\" name=\"call\"></ion-icon>\n                  <ion-label><a href=\"tel:{{visitorService.selectedVisitor.mobileNumber}}\" style=\"text-decoration: none; color:#000; cursor: pointer;\">{{visitorService.selectedVisitor.mobileNumber}}</a></ion-label>\n              </ion-chip>\n              <ion-text color=\"secondary\">\n                  <h1>\n                      Address\n                  </h1>\n              </ion-text>\n              <ion-icon color=\"primary\" name=\"home-outline\"></ion-icon>\n              <ion-text>&nbsp;{{visitorService.selectedVisitor.adress}}\n              </ion-text><br/><br/>\n\n              <ion-icon color=\"primary\" name=\"location-outline\"></ion-icon>\n              <ion-text><strong>&nbsp;Coming From: </strong></ion-text>\n              <ion-text>{{visitorService.selectedVisitor.fromPlace}}</ion-text><br/>\n\n              <ion-icon color=\"primary\" name=\"globe-outline\"></ion-icon>\n              <ion-text><strong>&nbsp;Company: </strong></ion-text>\n              <ion-text>{{visitorService.selectedVisitor.company}}</ion-text><br/>\n\n              <ion-icon color=\"primary\" name=\"body-outline\"></ion-icon>\n              <ion-text ><strong>&nbsp;Person visiting in RWS: </strong></ion-text>\n              <ion-text >{{visitorService.selectedVisitor.personInSdl}}</ion-text><br/><br/>\n\n              <ion-icon color=\"primary\" name=\"log-in-outline\"></ion-icon>\n              <ion-text><strong>&nbsp;Check In Date and Time : </strong></ion-text>\n              <ion-text>{{visitorService.selectedVisitor.loginDateTime | date: \"yyyy/MM/dd HH:mm:ss\"}}</ion-text><br/>\n              <ion-icon color=\"primary\" name=\"log-out-outline\"></ion-icon>\n              <ion-text><strong>&nbsp;Check Out Date and Time: </strong></ion-text>\n              <ion-text *ngIf=\"visitorService.selectedVisitor.logoutDateTime != undefined\">{{visitorService.selectedVisitor.logoutDateTime | date: \"yyyy/MM/dd HH:mm:ss\"}}</ion-text>\n              <ion-text *ngIf=\"visitorService.selectedVisitor.logoutDateTime == undefined\">Still not logged out</ion-text><br/><br/>\n\n              <ion-button *ngIf=\"visitorService.selectedVisitor.logoutDateTime == undefined\" shape=\"round\" color=\"secondary\" (click)=\"printBadgePDF(visitorService.selectedVisitor)\">\n                  <ion-icon name=\"print-outline\"></ion-icon>\n              </ion-button>\n\n              <ion-button *ngIf=\"visitorService.selectedVisitor.logoutDateTime == undefined\" shape=\"round\" color=\"warning\" (click) =\"logout(visitorService.selectedVisitor.visitorId)\">\n                  <ion-icon name=\"log-out-outline\"></ion-icon>\n              </ion-button>\n              <!--\n              <ion-button shape=\"round\" color=\"danger\" (click) =\"showConfirmAlert(visitorService.selectedVisitor.visitorId)\">\n                  <ion-icon name=\"trash\"></ion-icon>\n              </ion-button>-->\n          </div>\n      </ion-card-content>\n      <ion-card class=\"photoCard\">\n          <ion-card-header>\n              Photo\n          </ion-card-header>\n          <ion-card-content>\n              <img src=\"{{this.imageUrl}}/{{visitorService.selectedVisitor.picture}}\" />\n          </ion-card-content>\n      </ion-card>\n      <ion-card class=\"photoSignature\">\n          <ion-card-header>\n              Signature\n          </ion-card-header>\n          <ion-card-content>\n              <img src=\"{{this.imageUrl}}/{{visitorService.selectedVisitor.signature}}\" />\n          </ion-card-content>\n      </ion-card>\n  </ion-card>\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/visitorDetailsTab/visitorDetailsTab.page.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/visitorDetailsTab/visitorDetailsTab.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"success\">\n    <ion-buttons>\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>\n      Visitor Entry ({{this.userName}})\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-segment class=\"segment\" (ionChange)=\"segmentChanged($event)\" value=\"false\">\n    <ion-segment-button value=\"false\">\n      <nobr>\n        <ion-icon class=\"segmentText\" name=\"people-circle-outline\" color=\"warning\"></ion-icon>&nbsp;&nbsp;<ion-label class=\"segmentText\" color=\"tertiary\">Visitor</ion-label>\n      </nobr>\n      </ion-segment-button>\n    <ion-segment-button value=\"true\">\n      <nobr>\n        <ion-icon class=\"segmentText\" name=\"person-add-outline\" color=\"warning\"></ion-icon>&nbsp;&nbsp;<ion-label class=\"segmentText\" color=\"tertiary\">Employee</ion-label>\n      </nobr>\n      </ion-segment-button>\n  </ion-segment>\n  <form  [formGroup] =\"form\">\n    <div id=\"visitorDetailEntry\" [ngClass]=\"{'show':!this.isEmployee, 'hide':this.isEmployee }\">\n      <div class=\"leftContent\">\n        <ion-card>\n          <ion-card-content>\n             <!--<ion-content>--> \n                <!--Name:Start-->\n                <ion-item >\n                  <ion-label color=\"primary\" position =\"floating\">Visitors name</ion-label>\n                  <ion-input  inputmode=\"text\" required name=\"visitorName\" formControlName=\"visitorName\" ></ion-input>\n                </ion-item>\n                <div *ngFor=\"let error of errorMessages.visitorName\">\n                  <ng-container *ngIf=\"visitorName.hasError(error.type) && (visitorName.dirty || visitorName.touched)\">\n                    <small class=\"error-message\">{{error.message}}</small>\n                  </ng-container>\n                </div>\n                <!--Name:End-->\n                <!--Email:Start-->\n                <ion-item >\n                  <ion-label color=\"primary\" position =\"floating\">Email</ion-label>\n                  <ion-input inputmode=\"email\" type=\"email\" name=\"visitorsName\" formControlName =\"email\"></ion-input>\n                </ion-item>\n                <div *ngFor=\"let error of errorMessages.email\">\n                  <ng-container *ngIf=\"email.hasError(error.type) && (email.dirty || email.touched)\">\n                  <small class=\"error-message\">{{error.message}}</small>\n                  </ng-container>\n                </div>\n                <!--Email:End-->\n                <!--Mobile:Start-->\n                <ion-item >\n                  <ion-label color=\"primary\" position =\"floating\">Mobile Number</ion-label>\n                  <ion-input inputmode=\"tel\" name=\"Mobile Number\"  formControlName =\"mobileNumber\"></ion-input>\n                </ion-item>\n                <div *ngFor=\"let error of errorMessages.mobileNumber\">\n                  <ng-container *ngIf=\"mobileNumber.hasError(error.type) && (mobileNumber.dirty || mobileNumber.touched)\">\n                  <small class=\"error-message\">{{error.message}}</small>\n                  </ng-container>\n                </div>\n                <!--Mobile:End-->\n              <!--</ion-content>-->\n          </ion-card-content>\n        </ion-card>\n        <ion-card>\n          <ion-card-content>\n            <!---->\n              <!--Address:Start-->\n              <ion-item>\n                <ion-label color=\"primary\" position =\"floating\">Address</ion-label>\n                <ion-textarea  inputmode=\"text\"  name=\"Address\" formControlName =\"adress\"></ion-textarea>\n              </ion-item>\n              <div *ngFor=\"let error of errorMessages.adress\">\n                <ng-container *ngIf=\"adress.hasError(error.type) && (adress.dirty || adress.touched)\">\n                <small class=\"error-message\">{{error.message}}</small>\n                </ng-container>\n              </div>\n              <!--Address:End-->\n            <!---->\n          </ion-card-content>\n        </ion-card>\n        <ion-card>\n          <ion-card-content>\n            \n              <!--From Place:Start-->\n              <ion-item>\n                <ion-label color=\"primary\" position =\"floating\">From Place Name</ion-label>\n                <ion-input  inputmode=\"text\"  name=\"FromPlace\" formControlName =\"fromPlace\"></ion-input>\n              </ion-item> \n              <div *ngFor=\"let error of errorMessages.fromPlace\">\n                <ng-container *ngIf=\"fromPlace.hasError(error.type) && (fromPlace.dirty || fromPlace.touched)\">\n                <small class=\"error-message\">{{error.message}}</small>\n                </ng-container>\n              </div>\n              <!--From Place:End-->\n              <!--From Place:Start-->\n              <ion-item>\n                <ion-label color=\"primary\" position =\"floating\">Company</ion-label>\n                <ion-input  inputmode=\"text\"  name=\"Company\" formControlName =\"company\"></ion-input>\n              </ion-item> \n              <div *ngFor=\"let error of errorMessages.Company\">\n                <ng-container *ngIf=\"company.hasError(error.type) && (company.dirty || company.touched)\">\n                <small class=\"error-message\">{{error.message}}</small>\n                </ng-container>\n              </div>\n              <!--From Place:End-->\n              <!--From PersonToVisit:Start-->\n              <div class=\"personToVisit\">\n                <ion-item>\n                  <ion-label color=\"primary\" position =\"floating\">Person visiting in RWS</ion-label>\n                  <ion-input id=\"userNave\" inputmode=\"text\"  name=\"PersonInSdl\" formControlName =\"personInSdl\" value={{this.visitorService.selectedUserEmail}}></ion-input>\n                </ion-item> \n                <div *ngFor=\"let error of errorMessages.personInSdl\">\n                  <ng-container *ngIf=\"personInSdl.hasError(error.type) && (personInSdl.dirty || personInSdl.touched)\">\n                  <small class=\"error-message\">{{error.message}}</small>\n                  </ng-container>\n                </div>\n              </div>\n              <div class=\"personToVisitSearch\">\n                <ion-button (click)=\"openSelectUser()\"> <ion-icon name=\"search-outline\"></ion-icon>\n                  &nbsp;&nbsp;Search RWS User</ion-button>\n              </div>\n              <!--From PersonToVisit:End-->\n            \n          </ion-card-content>\n        </ion-card>\n      </div>\n      <div class=\"rightContent\">\n        <ion-card>\n          <ion-card-content>\n            \n              <!--Photo:Start-->\n              <div class=\"photoDiv\" (click)=\"opencamera()\">\n                <ion-item *ngFor=\"let photo of photos; index as position\">\n                    <ion-img src=\"{{ photo.webviewPath }}\" (click)=\"opencamera()\"\n                      alt=\"Your Photo\" alt=\"Missing image\" onerror=\"this.onerror=null\" this.src=\"../../assets/Camera.jpg\">\n                    </ion-img>\n                </ion-item>\n              </div>\n              <ion-fab horizontal=\"end\" vertical=\"center\" slot=\"fixed\">\n                <ion-fab-button color=\"tertiary\" (click)=\"opencamera()\">\n                    <ion-icon name=\"camera-outline\"></ion-icon>\n                </ion-fab-button>\n               </ion-fab>\n              <!--Photo:End-->\n            \n          </ion-card-content>\n        </ion-card>\n        <ion-card>\n          <ion-card-content>\n            \n              <!--Signature:Start-->\n              <div class=\"signatureDiv\">\n                <img src=\"../../assets/signature.png\" [hidden]=\"this.signatureMaskHidden\" (mouseover)=\"hideImage()\" (mousedown)=\"hideImage()\" (click)=\"hideImage()\">\n                <ion-item>\n                  <signature-pad #signatureCanvas [options]=\"signaturePadOptions\" id=\"signatureCanvas\" (onBeginEvent)=\"drawStart()\" (onEndEvent)=\"drawComplete()\" >\n                  </signature-pad>\n                </ion-item>\n              </div>\n              <ion-fab horizontal=\"end\" vertical=\"center\" slot=\"fixed\">\n                <ion-fab-button color=\"danger\" [disabled]=\"!this.signatureImage\" (click)=\"drawClear()\">\n                  <ion-icon name=\"close-circle-outline\"></ion-icon>\n                </ion-fab-button>\n               </ion-fab>\n              <!--Signature:End-->\n            \n          </ion-card-content>\n        </ion-card>\n        <div class=\"buttons\">\n          <ion-button color=\"danger\" (click)=\"resetForm(form)\" >\n            <ion-icon name=\"refresh-circle-outline\"></ion-icon>\n            &nbsp;&nbsp;Reset\n          </ion-button><br/>\n          <ion-button color=\"tertiary\" type=\"submit\" [disabled]=\"!form.valid\" (click) =\"onSubmit(form)\" >\n            <ion-icon name=\"save-outline\"></ion-icon>\n            &nbsp;&nbsp;Check In\n          </ion-button>\n        </div>\n      </div>\n    </div>\n  </form>\n  <div id=\"employeeDetailEntry\" [ngClass]=\"{'show':this.isEmployee, 'hide':!this.isEmployee }\">\n    <ion-searchbar (ionInput)=\"filterUserData($event)\" value=\"{{this.selectedUser.displayName}}\"></ion-searchbar>\n    &nbsp;&nbsp;<ion-text color=\"success\" *ngIf=\"this.selectedUser.displayName!=''\">Selected User: {{this.selectedUser.displayName}} {{this.selectedUser.email}}</ion-text>\n    &nbsp;&nbsp;<ion-button *ngIf=\"this.selectedUser.displayName!=''\" color=\"tertiary\" type=\"submit\" (click) =\"loginUser()\" >\n      <ion-icon name=\"save-outline\"></ion-icon>\n      &nbsp;&nbsp;Check In\n    </ion-button>\n    <ion-list *ngIf=\"isEmployeeDropDownVisible\">\n      <ion-item (click)=\"selectVal(item)\" *ngFor=\"let item of usersList\">{{item.displayName}}, {{item.email}}</ion-item>\n    </ion-list>\n  </div>\n</ion-content>\n\n");

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _auth_auth_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth/auth.guard */ "./src/app/auth/auth.guard.ts");





const routes = [
    {
        path: '',
        redirectTo: 'tabs',
        pathMatch: 'full'
    },
    {
        path: 'auth',
        loadChildren: () => __webpack_require__.e(/*! import() | auth-auth-module */ "auth-auth-module").then(__webpack_require__.bind(null, /*! ./auth/auth.module */ "./src/app/auth/auth.module.ts")).then(m => m.AuthPageModule)
    },
    {
        path: 'tabs',
        loadChildren: () => __webpack_require__.e(/*! import() | tabs-tabs-module */ "tabs-tabs-module").then(__webpack_require__.bind(null, /*! ./tabs/tabs.module */ "./src/app/tabs/tabs.module.ts")).then(m => m.TabsPageModule),
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]]
    },
    {
        path: 'visitorDetailsTab',
        loadChildren: () => Promise.all(/*! import() | visitorDetailsTab-visitorDetailsTab-module */[__webpack_require__.e("common"), __webpack_require__.e("visitorDetailsTab-visitorDetailsTab-module")]).then(__webpack_require__.bind(null, /*! ./visitorDetailsTab/visitorDetailsTab.module */ "./src/app/visitorDetailsTab/visitorDetailsTab.module.ts")).then(m => m.VisitorDetailsTabPageModule),
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]]
    },
    {
        path: 'visitor-details',
        loadChildren: () => __webpack_require__.e(/*! import() | modals-visitor-details-visitor-details-module */ "modals-visitor-details-visitor-details-module").then(__webpack_require__.bind(null, /*! ./modals/visitor-details/visitor-details.module */ "./src/app/modals/visitor-details/visitor-details.module.ts")).then(m => m.VisitorDetailsPageModule)
    },
    {
        path: 'changepassword',
        loadChildren: () => __webpack_require__.e(/*! import() | changepassword-changepassword-module */ "changepassword-changepassword-module").then(__webpack_require__.bind(null, /*! ./changepassword/changepassword.module */ "./src/app/changepassword/changepassword.module.ts")).then(m => m.ChangepasswordPageModule),
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]]
    },
    {
        path: 'searchuser',
        loadChildren: () => __webpack_require__.e(/*! import() | modals-searchuser-searchuser-module */ "modals-searchuser-searchuser-module").then(__webpack_require__.bind(null, /*! ./modals/searchuser/searchuser.module */ "./src/app/modals/searchuser/searchuser.module.ts")).then(m => m.SearchuserPageModule)
    },
    {
        path: 'registeruser',
        loadChildren: () => __webpack_require__.e(/*! import() | registeruser-registeruser-module */ "registeruser-registeruser-module").then(__webpack_require__.bind(null, /*! ./registeruser/registeruser.module */ "./src/app/registeruser/registeruser.module.ts")).then(m => m.RegisteruserPageModule)
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./auth/auth.service */ "./src/app/auth/auth.service.ts");






let AppComponent = class AppComponent {
    constructor(platform, splashScreen, statusBar, authService) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.authService = authService;
        this.initializeApp();
    }
    ionViewWillEnter() { }
    initializeApp() {
        this.platform.ready().then(() => {
            this.statusBar.styleDefault();
            this.splashScreen.hide();
        });
    }
    logout() {
        this.authService.logout();
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"] },
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"] }
];
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")).default]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var angular2_signaturepad__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! angular2-signaturepad */ "./node_modules/angular2-signaturepad/__ivy_ngcc__/index.js");
/* harmony import */ var angular2_signaturepad__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(angular2_signaturepad__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _visitorDetailsTab_visitorDetailsTab_page__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./visitorDetailsTab/visitorDetailsTab.page */ "./src/app/visitorDetailsTab/visitorDetailsTab.page.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _ionic_native_file_transfer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic-native/file-transfer */ "./node_modules/@ionic-native/file-transfer/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_document_viewer_ngx__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ionic-native/document-viewer/ngx */ "./node_modules/@ionic-native/document-viewer/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _services_capacitordownload_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./services/capacitordownload.service */ "./src/app/services/capacitordownload.service.ts");
/* harmony import */ var _services_download_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./services/download.service */ "./src/app/services/download.service.ts");




















//import {Transfer} from '@ionic-native/transfer'
/*import { Ng2SearchPipeModule} from 'ng2-search-filter';
import {Ng2OrderModule} from 'ng2-order-pipe'
import { NgxPaginationModule} from 'ngx-pagination'; */
let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"]],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"].forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
            angular2_signaturepad__WEBPACK_IMPORTED_MODULE_4__["SignaturePadModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ReactiveFormsModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_13__["HttpClientModule"],
        ],
        providers: [
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__["StatusBar"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__["SplashScreen"],
            _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_10__["Camera"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavParams"],
            _visitorDetailsTab_visitorDetailsTab_page__WEBPACK_IMPORTED_MODULE_11__["VisitorDetailsTabPage"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_15__["File"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_16__["FileOpener"],
            _ionic_native_document_viewer_ngx__WEBPACK_IMPORTED_MODULE_17__["DocumentViewer"],
            _services_capacitordownload_service__WEBPACK_IMPORTED_MODULE_18__["CapacitordownloadService"],
            _services_download_service__WEBPACK_IMPORTED_MODULE_19__["DownloadService"],
            _ionic_native_file_transfer__WEBPACK_IMPORTED_MODULE_14__["FileTransferObject"],
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicRouteStrategy"] }
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/auth/auth.guard.ts":
/*!************************************!*\
  !*** ./src/app/auth/auth.guard.ts ***!
  \************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.service */ "./src/app/auth/auth.service.ts");




let AuthGuard = class AuthGuard {
    constructor(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    canLoad(route, segments) {
        if (!this.authService.userAuthenticated) {
            this.router.navigateByUrl('/auth');
        }
        return this.authService.userAuthenticated;
    }
};
AuthGuard.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
AuthGuard = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AuthGuard);



/***/ }),

/***/ "./src/app/auth/auth.service.ts":
/*!**************************************!*\
  !*** ./src/app/auth/auth.service.ts ***!
  \**************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _models_settings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../models/settings */ "./src/app/models/settings.ts");





let AuthService = class AuthService {
    constructor(http, router) {
        this.http = http;
        this.router = router;
        this.userEmail = "";
        this.userPassword = "";
        this.errorMessage = "";
        this._userIsAuthenticated = false;
    }
    get userAuthenticated() {
        return this._userIsAuthenticated;
    }
    login(rootURL) {
        if ((this.userEmail != "") && (this.userPassword != "")) {
            if (this.validateEmail(this.userEmail)) {
                var user = {
                    "email": this.userEmail,
                    "password": this.userPassword
                };
                this.http.post(rootURL + '/Authentication/Login', user).subscribe((resp) => {
                    _models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].token = resp.token;
                    _models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].userEmail = resp.userEmail;
                    _models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].userName = resp.userName;
                    _models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].userId = resp.userId;
                    this._userIsAuthenticated = true;
                    this.router.navigateByUrl('/tabs/visitorDetailsTab');
                }, (error) => {
                    this.errorMessage = "Login failed! Please check the credential!";
                });
            }
            else {
                this.userEmail = "";
                this.errorMessage = "Please enter a valid email id!";
            }
        }
        else {
            this.errorMessage = "Please enter email id and password!";
        }
    }
    validateEmail(mail) {
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
            return (true);
        }
        return (false);
    }
    logout() {
        _models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].token = "";
        _models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].userEmail = "";
        _models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].userName = "";
        _models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].userId = 0;
        this.userEmail = "";
        this.userPassword = "";
        this._userIsAuthenticated = false;
        this.router.navigateByUrl('/auth');
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
AuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ "./src/app/modals/searchuser/searchuser.page.scss":
/*!********************************************************!*\
  !*** ./src/app/modals/searchuser/searchuser.page.scss ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21vZGFscy9zZWFyY2h1c2VyL3NlYXJjaHVzZXIucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/modals/searchuser/searchuser.page.ts":
/*!******************************************************!*\
  !*** ./src/app/modals/searchuser/searchuser.page.ts ***!
  \******************************************************/
/*! exports provided: SearchuserPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchuserPage", function() { return SearchuserPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_models_user__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/models/user */ "./src/app/models/user.ts");
/* harmony import */ var src_app_services_visitorsdetails_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/visitorsdetails.service */ "./src/app/services/visitorsdetails.service.ts");





let SearchuserPage = class SearchuserPage {
    constructor(modalController, visitorService) {
        this.modalController = modalController;
        this.visitorService = visitorService;
        this.isEmployeeDropDownVisible = false;
    }
    ngOnInit() {
        this.selectedUser = new src_app_models_user__WEBPACK_IMPORTED_MODULE_3__["User"];
    }
    filterUserData(event) {
        this.usersList = this.visitorService.allUserList;
        this.selectedUser = new src_app_models_user__WEBPACK_IMPORTED_MODULE_3__["User"];
        const val = event.target.value;
        if (val && val.trim() != '' && val.length > 0) {
            this.isEmployeeDropDownVisible = true;
            this.usersList = this.usersList.filter((item) => {
                return (item.displayName.toLowerCase().indexOf(val.toLowerCase()) > -1);
            });
        }
        else {
            this.isEmployeeDropDownVisible = false;
        }
    }
    selectVal(user) {
        this.selectedUser = user;
        this.isEmployeeDropDownVisible = false;
        //console.log(this.selectedUser);
    }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const onClosedData = this.selectedUser;
            yield this.modalController.dismiss(onClosedData);
        });
    }
    done() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.visitorService.selectedUserEmail = this.selectedUser.email;
            this.closeModal();
        });
    }
};
SearchuserPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: src_app_services_visitorsdetails_service__WEBPACK_IMPORTED_MODULE_4__["VisitorsdetailsService"] }
];
SearchuserPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-searchuser',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./searchuser.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/modals/searchuser/searchuser.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./searchuser.page.scss */ "./src/app/modals/searchuser/searchuser.page.scss")).default]
    })
], SearchuserPage);



/***/ }),

/***/ "./src/app/modals/visitor-details/visitor-details.page.scss":
/*!******************************************************************!*\
  !*** ./src/app/modals/visitor-details/visitor-details.page.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".visitorDetailCardContent {\n  float: left;\n  width: 50%;\n}\n\n.photoCard {\n  float: right;\n  width: 200px;\n}\n\n.photoSignature {\n  float: right;\n  width: 200px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zdXByYWJoYXRwYXVsL0dpdC9Sb290L0lvbmljL1Zpc2l0b3JCb29rL0FwcC9kYWlseVZpc2l0b3JzL3NyYy9hcHAvbW9kYWxzL3Zpc2l0b3ItZGV0YWlscy92aXNpdG9yLWRldGFpbHMucGFnZS5zY3NzIiwic3JjL2FwcC9tb2RhbHMvdmlzaXRvci1kZXRhaWxzL3Zpc2l0b3ItZGV0YWlscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsVUFBQTtBQ0NKOztBRENJO0VBQ0ksWUFBQTtFQUNBLFlBQUE7QUNFUjs7QURBSTtFQUNJLFlBQUE7RUFDQSxZQUFBO0FDR1IiLCJmaWxlIjoic3JjL2FwcC9tb2RhbHMvdmlzaXRvci1kZXRhaWxzL3Zpc2l0b3ItZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudmlzaXRvckRldGFpbENhcmRDb250ZW50e1xuICAgIGZsb2F0OiBsZWZ0O1xuICAgIHdpZHRoOiA1MCU7XG59XG4gICAgLnBob3RvQ2FyZHtcbiAgICAgICAgZmxvYXQ6IHJpZ2h0O1xuICAgICAgICB3aWR0aDogMjAwcHg7XG4gICAgfVxuICAgIC5waG90b1NpZ25hdHVyZXtcbiAgICAgICAgZmxvYXQ6IHJpZ2h0O1xuICAgICAgICB3aWR0aDogMjAwcHg7XG4gICAgfSIsIi52aXNpdG9yRGV0YWlsQ2FyZENvbnRlbnQge1xuICBmbG9hdDogbGVmdDtcbiAgd2lkdGg6IDUwJTtcbn1cblxuLnBob3RvQ2FyZCB7XG4gIGZsb2F0OiByaWdodDtcbiAgd2lkdGg6IDIwMHB4O1xufVxuXG4ucGhvdG9TaWduYXR1cmUge1xuICBmbG9hdDogcmlnaHQ7XG4gIHdpZHRoOiAyMDBweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/modals/visitor-details/visitor-details.page.ts":
/*!****************************************************************!*\
  !*** ./src/app/modals/visitor-details/visitor-details.page.ts ***!
  \****************************************************************/
/*! exports provided: VisitorDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VisitorDetailsPage", function() { return VisitorDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_visitorsdetails_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/visitorsdetails.service */ "./src/app/services/visitorsdetails.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_models_settings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/models/settings */ "./src/app/models/settings.ts");





let VisitorDetailsPage = class VisitorDetailsPage {
    constructor(toastCtrl, visitorService, modalController, alertController) {
        this.toastCtrl = toastCtrl;
        this.visitorService = visitorService;
        this.modalController = modalController;
        this.alertController = alertController;
    }
    logout(id) {
        this.visitorService.logout(id, src_app_models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].rootURL, src_app_models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].token, src_app_models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].userId).subscribe(response => {
            var detailList = response;
            if (detailList.length > 0) {
                //visitorService.selectedVisitor
                detailList.forEach((visitor) => {
                    if (visitor.visitorId == this.visitorService.selectedVisitor.visitorId) {
                        this.visitorService.selectedVisitor = visitor;
                    }
                });
                this.openToast("Logout Successfully.");
            }
        });
    }
    showConfirmAlert(id) {
        let alertConfirm = this.alertController.create({
            header: 'Delete Items',
            message: 'Are You Sure to delete this visitor entry?',
            buttons: [
                {
                    text: 'No',
                    role: 'cancel',
                    handler: () => {
                        console.log('No clicked');
                    }
                },
                {
                    text: 'Yes',
                    handler: () => {
                        this.delete(id);
                    }
                }
            ]
        }).then(response => response.present());
    }
    delete(id) {
        this.visitorService.delete(id, src_app_models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].rootURL, src_app_models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].token, src_app_models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].userId).subscribe(response => {
            var detailList = response;
            if (detailList.length > 0) {
                this.openToast("Deleted Successfully.");
                this.closeModal();
            }
        });
    }
    printBadgePDF(visitor) {
        this.visitorService.printBadgePDF(visitor.visitorId, src_app_models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].rootURL, src_app_models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].token).subscribe((data) => {
            var file = new Blob([data], { type: 'application/pdf' });
            var fileURL = URL.createObjectURL(file);
            // if you want to open PDF in new tab
            window.open(fileURL);
            var a = document.createElement('a');
            a.href = fileURL;
            a.target = '_blank';
            a.download = 'visitorBadge.pdf';
            document.body.appendChild(a);
            a.click();
        }, (error) => {
            console.log('getPDF error: ', error);
        });
    }
    ngOnInit() {
        //this.imageUrl = settings.rootURL.replace("/api","");
        this.imageUrl = src_app_models_settings__WEBPACK_IMPORTED_MODULE_4__["settings"].rootURL;
    }
    openToast(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                color: 'dark',
                duration: 4000,
                message: message
            }).then(toast => {
                toast.present();
            });
        });
    }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const onClosedData = "Wrapped Up!";
            yield this.modalController.dismiss(onClosedData);
        });
    }
};
VisitorDetailsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"] },
    { type: src_app_services_visitorsdetails_service__WEBPACK_IMPORTED_MODULE_2__["VisitorsdetailsService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] }
];
VisitorDetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-visitor-details',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./visitor-details.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/modals/visitor-details/visitor-details.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./visitor-details.page.scss */ "./src/app/modals/visitor-details/visitor-details.page.scss")).default]
    })
], VisitorDetailsPage);



/***/ }),

/***/ "./src/app/models/settings.ts":
/*!************************************!*\
  !*** ./src/app/models/settings.ts ***!
  \************************************/
/*! exports provided: settings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return settings; });
var settings = {
    token: "",
    rootURL: "https://apivisitor.azurewebsites.net/api",
    //rootURL:"http://localhost:5000/api",
    userEmail: "",
    userName: "",
    userId: 0
};


/***/ }),

/***/ "./src/app/models/user.ts":
/*!********************************!*\
  !*** ./src/app/models/user.ts ***!
  \********************************/
/*! exports provided: User */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
class User {
    constructor(object) {
        this.userId = object && object.userId || null;
        this.empowerUserId = object && object.empowerUserId || "";
        this.email = object && object.visitorEmailId || "";
        this.displayName = object && object.displayName || "";
        this.dateOfBirth = object && object.dateOfBirth || null;
        this.dateOfJoining = object && object.dateOfJoining || null;
        this.insertDateTime = object && object.insertDateTime || null;
        this.identityName = object && object.identityName || "";
        this.firstName = object && object.firstName || "";
        this.lastName = object && object.lastName || "";
        this.officeId = object && object.officeId || null;
    }
}


/***/ }),

/***/ "./src/app/models/visitor.ts":
/*!***********************************!*\
  !*** ./src/app/models/visitor.ts ***!
  \***********************************/
/*! exports provided: Visitor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Visitor", function() { return Visitor; });
class Visitor {
    constructor(object) {
        this.visitorId = object && object.visitorId || null;
        this.visitorName = object && object.visitorName || "";
        this.email = object && object.visitorEmailId || "";
        this.company = object && object.company || "";
        this.mobileNumber = object && object.mobileNumber || null;
        this.adress = object && object.adress || "";
        this.fromPlace = object && object.fromPlace || null;
        this.signature = object && object.signature || "";
        this.loginDateTime = object && object.loginDateTime || null;
        this.logoutDateTime = object && object.logoutDateTime || null;
        this.isLogoutVisible = object && object.logoutTime || false;
        this.isDeleted = object && object.isDeleted || false;
        this.personInSdl = object && object.personInSdl || "";
        this.userId = object && object.userId || 0;
    }
}


/***/ }),

/***/ "./src/app/services/capacitordownload.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/services/capacitordownload.service.ts ***!
  \*******************************************************/
/*! exports provided: CapacitordownloadService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CapacitordownloadService", function() { return CapacitordownloadService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_document_viewer_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/document-viewer/ngx */ "./node_modules/@ionic-native/document-viewer/__ivy_ngcc__/ngx/index.js");







//import { rejects } from 'assert';
//import { resolve } from 'dns';
const { Filesystem, Storage } = _capacitor_core__WEBPACK_IMPORTED_MODULE_3__["Plugins"];
const FILE_KEY = "files";
let CapacitordownloadService = class CapacitordownloadService {
    //constructor(){}
    constructor(http, file, documentViewer, fileOpener) {
        this.http = http;
        this.file = file;
        this.documentViewer = documentViewer;
        this.fileOpener = fileOpener;
        this.downloadUrl = '';
        this.myFiles = [];
        this.downloadProgress = 0;
        this.pdfUrl = "https://apivisitor.azurewebsites.net/StaticFiles/visitorBadge123.pdf";
        this.convertBlobToBase64 = (blob) => new Promise((resolve, rejects) => {
            const reader = new FileReader;
            reader.onerror = rejects;
            reader.onload = () => {
                resolve(reader.result);
            };
            reader.readAsDataURL(blob);
        });
        this.loadFile();
    }
    loadFile() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const videoList = yield Storage.get({ key: FILE_KEY });
            this.myFiles = JSON.parse(videoList.value) || [];
            console.log("Loding File....");
        });
    }
    getMimetype(name) {
        if (name.indexOf('.pdf') >= 0) {
            return 'application/pdf';
        }
        else if (name.indexOf('.csv') >= 0) {
            return 'text/csv';
        }
        else if (name.indexOf('.png') >= 0) {
            return 'image/png';
        }
        else if (name.indexOf('.mp4') >= 0) {
            return 'video/mp4';
        }
    }
    download(url) {
        url = this.pdfUrl;
        this.downloadUrl = url ? url : this.downloadUrl;
        console.log("download....");
        this.http.get(this.downloadUrl, {
            responseType: 'blob',
            reportProgress: true,
            observe: 'events'
        }).subscribe((event) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log("subscribe....");
            if (event.type === _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].DownloadProgress) {
                this.downloadProgress = Math.round((100 * event.loaded) / event.total);
            }
            else if (event.type === _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpEventType"].Response) {
                this.downloadProgress = 0;
                console.log(event);
                // console.log(await this.convertBlobToBase64(event.body) as string);
                const name = this.downloadUrl.substr(this.downloadUrl.lastIndexOf('/') + 1);
                const base64 = yield this.convertBlobToBase64(event.body);
                console.log("Name" + name);
                const saveFile = yield Filesystem.writeFile({
                    path: name,
                    data: base64,
                    directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_3__["FilesystemDirectory"].Documents,
                    encoding: _capacitor_core__WEBPACK_IMPORTED_MODULE_3__["FilesystemEncoding"].UTF8
                    //directory:this.file.documentsDirectory
                }).then((writeFileResult) => {
                    console.log("Write File Result: " + writeFileResult);
                    Filesystem.getUri({
                        directory: _capacitor_core__WEBPACK_IMPORTED_MODULE_3__["FilesystemDirectory"].Documents,
                        path: name
                    }).then((getUriResult) => {
                        const path = getUriResult.uri;
                        console.log("uri: " + path);
                        const options = {
                            title: 'My PDF'
                        };
                        this.documentViewer.viewDocument('assets/visitorDetailsPDF.pdf', 'application/pdf', options);
                        //this.documentViewer.viewDocument(path, 'application/pdf', {})
                        /*this.fileOpener.open(path, 'application/pdf')
                        .then(() => console.log('File is opened'))
                        .catch(error => console.log('Error openening file: ', error));
          */
                        this.myFiles.unshift(path);
                        Storage.set({
                            key: FILE_KEY,
                            value: JSON.stringify(this.myFiles)
                        });
                    }, (error) => {
                        console.log(error);
                    });
                });
                //console.log("uri:" + saveFile.uri);
                // console.log("directory" + saveFile.directory);
                /*   const path = saveFile.uri;
                  const mimeType = this.getMimetype(name);
                  console.log(path, mimeType);
                 this.fileOpener.open(path, mimeType)
                  .then(()=> console.log('File is opened'))
                  .catch(()=>console.log("Error opening file"));
          */
            }
        }));
    } /**/
};
CapacitordownloadService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_5__["File"] },
    { type: _ionic_native_document_viewer_ngx__WEBPACK_IMPORTED_MODULE_6__["DocumentViewer"] },
    { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_4__["FileOpener"] }
];
CapacitordownloadService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], CapacitordownloadService);



/***/ }),

/***/ "./src/app/services/download.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/download.service.ts ***!
  \**********************************************/
/*! exports provided: DownloadService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DownloadService", function() { return DownloadService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_native_file_transfer___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/file-transfer/ */ "./node_modules/@ionic-native/file-transfer/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _ionic_native_document_viewer_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/document-viewer/ngx */ "./node_modules/@ionic-native/document-viewer/__ivy_ngcc__/ngx/index.js");







let DownloadService = class DownloadService {
    constructor(file, platform, alertCtrl, transfer, documentViewer) {
        this.file = file;
        this.platform = platform;
        this.alertCtrl = alertCtrl;
        this.transfer = transfer;
        this.documentViewer = documentViewer;
    }
    downloadFile(fileName, url, token) {
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["from"])(this.performDownload(fileName, url, token));
    }
    performDownload(fileName, url, token) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // We added this check since this is only intended to work on devices and emulators 
            if (!this.platform.is('cordova')) {
                console.warn('Cannot download in local environment!');
                return;
            }
            var fileTransfer = new _ionic_native_file_transfer___WEBPACK_IMPORTED_MODULE_2__["FileTransferObject"]();
            let uri = encodeURI(url);
            let path = yield this.getDownloadPath();
            return fileTransfer.download(uri, path + fileName).then(result => {
                this.showAlert(true, fileName);
                let docUrl = result.toURL();
                this.documentViewer.viewDocument(docUrl, this.getMimetype(fileName), {});
            }, error => {
                this.showAlert(false, fileName);
                console.log("Error: " + error);
            });
        });
    }
    getDownloadPath() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.platform.is('ios')) {
                return this.file.documentsDirectory;
            }
            // To be able to save files on Android, we first need to ask the user for permission. 
            // We do not let the download proceed until they grant access
            /* await this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE).then(
                 result => {
                     if (!result.hasPermission) {
                         return this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.WRITE_EXTERNAL_STORAGE);
                     }
                 }
             );*/
            return this.file.externalRootDirectory + "/Download/";
        });
    }
    showAlert(hasPassed, fileName) {
        let title = hasPassed ? "Download complete!" : "Download failed!";
        let subTitle = hasPassed ? `Successfully downloaded ${fileName}.` : `There was a problem while downloading ${fileName}`;
        const alert = this.alertCtrl.create({
            message: title,
            subHeader: subTitle,
            buttons: ['OK']
        }).then(alert => alert.present());
    }
    getMimetype(name) {
        if (name.indexOf('.pdf') >= 0) {
            return 'application/pdf';
        }
        else if (name.indexOf('.csv') >= 0) {
            return 'text/csv';
        }
        else if (name.indexOf('.png') >= 0) {
            return 'image/png';
        }
        else if (name.indexOf('.mp4') >= 0) {
            return 'video/mp4';
        }
    }
};
DownloadService.ctorParameters = () => [
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_3__["File"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_native_file_transfer___WEBPACK_IMPORTED_MODULE_2__["FileTransferObject"] },
    { type: _ionic_native_document_viewer_ngx__WEBPACK_IMPORTED_MODULE_6__["DocumentViewer"] }
];
DownloadService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], DownloadService);



/***/ }),

/***/ "./src/app/services/loading.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/loading.service.ts ***!
  \*********************************************/
/*! exports provided: LoadingService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadingService", function() { return LoadingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let LoadingService = class LoadingService {
    constructor(loadingController) {
        this.loadingController = loadingController;
        this.isLoading = false;
    }
    present() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingController.create({
            // duration: 5000,
            }).then(a => {
                a.present().then(() => {
                    console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss().then(() => console.log('abort presenting'));
                    }
                });
            });
        });
    }
    dismiss() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingController.dismiss().then(() => console.log('dismissed'));
        });
    }
};
LoadingService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
LoadingService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], LoadingService);



/***/ }),

/***/ "./src/app/services/photo.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/photo.service.ts ***!
  \*******************************************/
/*! exports provided: PhotoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PhotoService", function() { return PhotoService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");



const { Camera, Filesystem, Storage } = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"];

let PhotoService = class PhotoService {
    constructor() {
        this.photos = [];
        this.content = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]("Default Subject");
        this.share = this.content.asObservable();
    }
    updateData(any) {
        this.content.next(any);
    }
    addNewToGallery() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const capturedPhoto = yield Camera.getPhoto({
                resultType: _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["CameraResultType"].Uri,
                source: _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["CameraSource"].Camera,
                quality: 100
            });
            this.photos.unshift({
                filepath: "soon...",
                webviewPath: capturedPhoto.webPath
            });
        });
    }
};
PhotoService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], PhotoService);



/***/ }),

/***/ "./src/app/services/visitorsdetails.service.ts":
/*!*****************************************************!*\
  !*** ./src/app/services/visitorsdetails.service.ts ***!
  \*****************************************************/
/*! exports provided: VisitorsdetailsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VisitorsdetailsService", function() { return VisitorsdetailsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _models_visitor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/visitor */ "./src/app/models/visitor.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _capacitordownload_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./capacitordownload.service */ "./src/app/services/capacitordownload.service.ts");
/* harmony import */ var _download_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./download.service */ "./src/app/services/download.service.ts");








//import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer';
//import { File } from '@ionic-native/file/ngx';
let VisitorsdetailsService = class VisitorsdetailsService {
    // private fileTransfer: FileTransferObject; 
    constructor(http, platform, alertController, downloadService, capacitordownloadService
    // private file: File,
    //    private alertCtrl: AlertController
    ) {
        this.http = http;
        this.platform = platform;
        this.alertController = alertController;
        this.downloadService = downloadService;
        this.capacitordownloadService = capacitordownloadService;
        this.allVisitorList = [];
        this.allUserList = [];
        this.selectedUserEmail = "";
        this.fetchingAllRecords = false;
        this.observableVisitorList = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this.observableUserList = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
    }
    downloadPDFVisitorDetails(id, rootURL, token) {
        /*  const url = rootURL+'/VisitorDetails/visitorDetailsPDF?id=' + id;
         this.fileTransfer = FileTransfer.create();
         this.fileTransfer.download(url, this.files.externalRootDirectory + 'visitorDetails_'+Date.now()+'.pdf', true).then((entry) => {
         console.log('download complete: ' + entry.toURL());
       }, (error) => {
         // handle error
       });*/
        /*
         const headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization':'Bearer ' + token
        });
          return this.http.get(rootURL+'/VisitorDetails/visitorDetailsPDF?id=' + id, {headers: headers, responseType: 'blob' as 'json' });*/
        if (this.platform.is('cordova')) {
            this.downloadService.downloadFile('visitorDetails_' + Date.now() + '.pdf', rootURL + '/VisitorDetails/visitorDetailsPDF?id=' + id, token).subscribe();
            //this.capacitordownloadService.download();
        }
        else {
            const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]({
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + token
            });
            return this.http.get(rootURL + '/VisitorDetails/visitorDetailsPDF?id=' + id, { headers: headers, responseType: 'blob' })
                .subscribe((data) => {
                var file = new Blob([data], { type: 'application/pdf' });
                var fileURL = URL.createObjectURL(file);
                // if you want to open PDF in new tab
                window.open(fileURL);
                var a = document.createElement('a');
                a.href = fileURL;
                //a.target      = '_blank';
                a.download = 'visitorDetails_' + Date.now() + '.pdf';
                document.body.appendChild(a);
                a.click();
            }, (error) => {
                console.log('getPDF error: ', error);
            });
        }
    }
    ngOnDestroy() {
        throw new Error('Method not implemented.');
    }
    postVisitorDetails(formData, signature, photoBase64String, rootURL, token, userId) {
        var requestHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]().set('Authorization', 'Bearer ' + token);
        var visitor = new _models_visitor__WEBPACK_IMPORTED_MODULE_3__["Visitor"]();
        visitor.visitorId = formData.visitorId;
        visitor.visitorName = formData.visitorName;
        visitor.email = formData.email;
        visitor.mobileNumber = Number(formData.mobileNumber);
        visitor.adress = formData.adress;
        visitor.fromPlace = formData.fromPlace;
        visitor.company = formData.company;
        visitor.signature = signature;
        visitor.picture = photoBase64String;
        visitor.loginDateTime = formData.loginDateTime;
        visitor.logoutDateTime = formData.logoutDateTime;
        visitor.isLogoutVisible = false;
        visitor.isDeleted = false;
        visitor.personInSdl = formData.personInSdl;
        visitor.userId = userId;
        return this.http.post(rootURL + '/VisitorDetails', visitor, { headers: requestHeaders });
    }
    getRWSUsers(rootURL) {
        //this.fetchingAllRecords = true;
        //var requestHeaders = new HttpHeaders().set('Authorization','Bearer ' + token);
        this.http.get(rootURL + '/Users/GetRWSUsers').subscribe((response) => {
            //console.log(response);
            this.allUserList = response;
            this.observableUserList.next(response);
            return this.allUserList;
        });
        return this.allUserList;
    }
    getVisitorDetails(rootURL, token, userId) {
        //console.log("Start");
        this.fetchingAllRecords = true;
        var requestHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]().set('Authorization', 'Bearer ' + token);
        this.http.get(rootURL + '/VisitorDetails?userId=' + userId, { headers: requestHeaders }).subscribe((response) => {
            //console.log(response);
            this.allVisitorList = response;
            this.fetchingAllRecords = false;
            this.observableVisitorList.next(response);
            return this.allVisitorList;
        });
        return this.allVisitorList;
    }
    getVisitorDetailsSingleDay(rootURL, token, userId) {
        var requestHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]().set('Authorization', 'Bearer ' + token);
        return this.http.get(rootURL + '/VisitorDetails?userId=' + userId, { headers: requestHeaders });
    }
    logout(id, rootURL, token, userId) {
        var requestHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]().set('Authorization', 'Bearer ' + token);
        return this.http.get(rootURL + '/VisitorDetails/logoutById?id=' + id + '&userId=' + userId, { headers: requestHeaders });
    }
    delete(id, rootURL, token, userId) {
        var requestHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]().set('Authorization', 'Bearer ' + token);
        return this.http.delete(rootURL + '/VisitorDetails/' + id + '/' + userId, { headers: requestHeaders });
    }
    sendEmailOfVisitorDetails(id, rootURL, emailId, token) {
        var requestHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]().set('Authorization', 'Bearer ' + token);
        return this.http.get(rootURL + '/VisitorDetails/emailDetails?id=' + id + '&emailId=' + emailId, { headers: requestHeaders });
    }
    printBadgePDF(id, rootURL, token) {
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        return this.http.get(rootURL + '/VisitorDetails/badgePDF?id=' + id, { headers: headers, responseType: 'blob' });
    }
    downloadPDF(ids, rootURL, token) {
        var str = ids.toString().split(",").join("&visitorIds=");
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': 'Bearer ' + token
        });
        return this.http.get(rootURL + '/VisitorDetails/downloadPDF?visitorIds=' + str, { headers: headers, responseType: 'blob' });
    }
    downloadExcel(ids, rootURL, token) {
        var str = ids.toString().split(",").join("&visitorIds=");
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]({
            'Content-Type': 'text/csv',
            'Accept': 'text/csv',
            'Authorization': 'Bearer ' + token
        });
        return this.http.get(rootURL + '/VisitorDetails/downloadCSV?visitorIds=' + str, { headers: headers, responseType: 'blob' });
    }
    emailReport(ids, rootURL, emailId, token) {
        var requestHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpHeaders"]().set('Authorization', 'Bearer ' + token);
        var str = ids.toString().split(",").join("&visitorIds=");
        return this.http.get(rootURL + '/VisitorDetails/emailReport?visitorIds=' + str + '&emailId=' + emailId, { headers: requestHeaders });
    }
    showVisitorDetails(visitor, url) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //url = url.replace("/api","");
            var message = `<table cellpadding=0 border=0>
      <tr>
        <td>Visitor Name</td>
        <td>${visitor.visitorName}</td>    
      </tr>
      <tr>
        <td>Email</td>
        <td>${visitor.email}</td>    
      </tr>
      <tr>
        <td>Mobile Number</td>
        <td>${visitor.mobileNumber}</td>    
      </tr>
      <tr>
        <td>Address</td>
        <td>${visitor.adress}</td>    
      </tr>
      <tr>
        <td>Form Place Name</td>
        <td>${visitor.fromPlace}</td>    
      </tr>
      <tr>
        <td>Log in Time</td>
        <td>${this.formatedTimestamp(visitor.loginDateTime)}</td>    
      </tr>
      <tr>
        <td>Log out Time</td>
        <td>${this.formatedTimestamp(visitor.logoutDateTime)}</td>    
      </tr>
      <tr>
        <td><img src="${url}/${visitor.signature}" /></td>
        <td><img src="${url}/${visitor.picture}" /></td>    
      </tr>
    </table>`;
            yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: "Visitor Details",
                message: message,
                buttons: ['OK']
            }).then(response => response.present());
        });
    }
    formatedTimestamp(dateTime) {
        if ((dateTime != undefined) || (dateTime != null)) {
            var date = dateTime.toString().split('T')[0];
            var time = dateTime.toString().split('T')[1];
            return `${date} ${time}`;
        }
        else {
            return "--";
        }
    }
};
VisitorsdetailsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _download_service__WEBPACK_IMPORTED_MODULE_7__["DownloadService"] },
    { type: _capacitordownload_service__WEBPACK_IMPORTED_MODULE_6__["CapacitordownloadService"] }
];
VisitorsdetailsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], VisitorsdetailsService);



/***/ }),

/***/ "./src/app/visitorDetailsTab/visitorDetailsTab.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/visitorDetailsTab/visitorDetailsTab.page.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".hide {\n  display: none;\n}\n\n.show {\n  display: block;\n}\n\n.error-message {\n  color: var(--ion-color-danger);\n}\n\n.segment {\n  height: 50px;\n}\n\n.segment .segmentText {\n  /*font-size: 25px;*/\n}\n\n#employeeDetailEntry {\n  padding: 10px;\n}\n\n.leftContent {\n  float: left;\n  width: 60%;\n}\n\n.leftContent .personToVisit {\n  width: calc(100% - 185px);\n  display: inline-block;\n}\n\n.leftContent .personToVisitSearch {\n  display: inline-block;\n  width: 185px;\n}\n\n.rightContent {\n  float: right;\n  width: 39%;\n}\n\n.rightContent .photoDiv {\n  width: 400px;\n  height: 210px;\n  background-image: url('Camera.jpg');\n  background-repeat: no-repeat;\n}\n\n.rightContent .signatureDiv {\n  border: 1px solid #ddd;\n  width: 331px;\n  height: 230px;\n}\n\n.rightContent .signatureDiv img {\n  width: 330px;\n  height: 228px;\n}\n\n.rightContent .signatureDiv .hydrated {\n  width: 100%;\n  height: 100%;\n}\n\n.rightContent .buttons {\n  float: right;\n  padding-right: 15px;\n  text-align: right;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zdXByYWJoYXRwYXVsL0dpdC9Sb290L0lvbmljL1Zpc2l0b3JCb29rL0FwcC9kYWlseVZpc2l0b3JzL3NyYy9hcHAvdmlzaXRvckRldGFpbHNUYWIvdmlzaXRvckRldGFpbHNUYWIucGFnZS5zY3NzIiwic3JjL2FwcC92aXNpdG9yRGV0YWlsc1RhYi92aXNpdG9yRGV0YWlsc1RhYi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0FDQ0o7O0FEQ0E7RUFDSSxjQUFBO0FDRUo7O0FEQUE7RUFDSSw4QkFBQTtBQ0dKOztBRERBO0VBQ0ksWUFBQTtBQ0lKOztBREhJO0VBQ0ksbUJBQUE7QUNLUjs7QURGQTtFQUNJLGFBQUE7QUNLSjs7QURIQTtFQUVJLFdBQUE7RUFDQSxVQUFBO0FDS0o7O0FESkk7RUFDSSx5QkFBQTtFQUNBLHFCQUFBO0FDTVI7O0FESkk7RUFDSSxxQkFBQTtFQUNBLFlBQUE7QUNNUjs7QURIQTtFQUVJLFlBQUE7RUFDQSxVQUFBO0FDS0o7O0FESkk7RUFDSSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1DQUFBO0VBQ0EsNEJBQUE7QUNNUjs7QURKSTtFQUNJLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNNUjs7QURMUTtFQUNJLFlBQUE7RUFDQSxhQUFBO0FDT1o7O0FETFE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQ09aOztBREpJO0VBQ0ksWUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUNNUiIsImZpbGUiOiJzcmMvYXBwL3Zpc2l0b3JEZXRhaWxzVGFiL3Zpc2l0b3JEZXRhaWxzVGFiLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oaWRlIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgfVxyXG4uc2hvdyB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICB9XHJcbi5lcnJvci1tZXNzYWdle1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXIpO1xyXG59XHJcbi5zZWdtZW50e1xyXG4gICAgaGVpZ2h0OiA1MHB4O1xyXG4gICAgLnNlZ21lbnRUZXh0e1xyXG4gICAgICAgIC8qZm9udC1zaXplOiAyNXB4OyovXHJcbiAgICB9XHJcbn1cclxuI2VtcGxveWVlRGV0YWlsRW50cnl7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG59XHJcbi5sZWZ0Q29udGVudFxyXG57XHJcbiAgICBmbG9hdDogbGVmdDtcclxuICAgIHdpZHRoOiA2MCU7XHJcbiAgICAucGVyc29uVG9WaXNpdHtcclxuICAgICAgICB3aWR0aDogY2FsYygxMDAlIC0gMTg1cHgpO1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIH1cclxuICAgIC5wZXJzb25Ub1Zpc2l0U2VhcmNoe1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICB3aWR0aDogMTg1cHg7XHJcbiAgICB9XHJcbn1cclxuLnJpZ2h0Q29udGVudFxyXG57XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICB3aWR0aDogMzklO1xyXG4gICAgLnBob3RvRGl2e1xyXG4gICAgICAgIHdpZHRoOiA0MDBweDsgXHJcbiAgICAgICAgaGVpZ2h0OiAyMTBweDtcclxuICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi4vLi4vYXNzZXRzL0NhbWVyYS5qcGcpO1xyXG4gICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICB9XHJcbiAgICAuc2lnbmF0dXJlRGl2e1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7IFxyXG4gICAgICAgIHdpZHRoOiAzMzFweDsgXHJcbiAgICAgICAgaGVpZ2h0OjIzMHB4O1xyXG4gICAgICAgIGltZ3tcclxuICAgICAgICAgICAgd2lkdGg6IDMzMHB4OyBcclxuICAgICAgICAgICAgaGVpZ2h0OjIyOHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICAuaHlkcmF0ZWR7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmJ1dHRvbnN7XHJcbiAgICAgICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDE1cHg7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICB9XHJcbn0iLCIuaGlkZSB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5zaG93IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5lcnJvci1tZXNzYWdlIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXIpO1xufVxuXG4uc2VnbWVudCB7XG4gIGhlaWdodDogNTBweDtcbn1cbi5zZWdtZW50IC5zZWdtZW50VGV4dCB7XG4gIC8qZm9udC1zaXplOiAyNXB4OyovXG59XG5cbiNlbXBsb3llZURldGFpbEVudHJ5IHtcbiAgcGFkZGluZzogMTBweDtcbn1cblxuLmxlZnRDb250ZW50IHtcbiAgZmxvYXQ6IGxlZnQ7XG4gIHdpZHRoOiA2MCU7XG59XG4ubGVmdENvbnRlbnQgLnBlcnNvblRvVmlzaXQge1xuICB3aWR0aDogY2FsYygxMDAlIC0gMTg1cHgpO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG4ubGVmdENvbnRlbnQgLnBlcnNvblRvVmlzaXRTZWFyY2gge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiAxODVweDtcbn1cblxuLnJpZ2h0Q29udGVudCB7XG4gIGZsb2F0OiByaWdodDtcbiAgd2lkdGg6IDM5JTtcbn1cbi5yaWdodENvbnRlbnQgLnBob3RvRGl2IHtcbiAgd2lkdGg6IDQwMHB4O1xuICBoZWlnaHQ6IDIxMHB4O1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi4vLi4vYXNzZXRzL0NhbWVyYS5qcGcpO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xufVxuLnJpZ2h0Q29udGVudCAuc2lnbmF0dXJlRGl2IHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2RkZDtcbiAgd2lkdGg6IDMzMXB4O1xuICBoZWlnaHQ6IDIzMHB4O1xufVxuLnJpZ2h0Q29udGVudCAuc2lnbmF0dXJlRGl2IGltZyB7XG4gIHdpZHRoOiAzMzBweDtcbiAgaGVpZ2h0OiAyMjhweDtcbn1cbi5yaWdodENvbnRlbnQgLnNpZ25hdHVyZURpdiAuaHlkcmF0ZWQge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuLnJpZ2h0Q29udGVudCAuYnV0dG9ucyB7XG4gIGZsb2F0OiByaWdodDtcbiAgcGFkZGluZy1yaWdodDogMTVweDtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/visitorDetailsTab/visitorDetailsTab.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/visitorDetailsTab/visitorDetailsTab.page.ts ***!
  \*************************************************************/
/*! exports provided: VisitorDetailsTabPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VisitorDetailsTabPage", function() { return VisitorDetailsTabPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_visitorsdetails_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/visitorsdetails.service */ "./src/app/services/visitorsdetails.service.ts");
/* harmony import */ var _models_visitor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/visitor */ "./src/app/models/visitor.ts");
/* harmony import */ var _services_photo_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/photo.service */ "./src/app/services/photo.service.ts");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _models_settings__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../models/settings */ "./src/app/models/settings.ts");
/* harmony import */ var _modals_visitor_details_visitor_details_page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../modals/visitor-details/visitor-details.page */ "./src/app/modals/visitor-details/visitor-details.page.ts");
/* harmony import */ var _modals_searchuser_searchuser_page__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../modals/searchuser/searchuser.page */ "./src/app/modals/searchuser/searchuser.page.ts");
/* harmony import */ var _models_user__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../models/user */ "./src/app/models/user.ts");
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../services/loading.service */ "./src/app/services/loading.service.ts");
















let VisitorDetailsTabPage = class VisitorDetailsTabPage {
    constructor(visitorService, http, photoService, camera, navParams, navCtrl, router, modalController, activatedRouter, formBuilder, alertController, popover, loadingControl) {
        this.visitorService = visitorService;
        this.http = http;
        this.photoService = photoService;
        this.camera = camera;
        this.navParams = navParams;
        this.navCtrl = navCtrl;
        this.router = router;
        this.modalController = modalController;
        this.activatedRouter = activatedRouter;
        this.formBuilder = formBuilder;
        this.alertController = alertController;
        this.popover = popover;
        this.loadingControl = loadingControl;
        this.photos = this.photoService.photos;
        this.signatureMaskHidden = false;
        this.isEmployee = false;
        this.userName = "";
        this.isEmployeeDropDownVisible = false;
        //#endregion
        this.errorMessages = {
            visitorName: [
                { type: "required", message: "Name is required" },
                { type: "maxlength", message: "Name can not be more than 100 charecter" }
            ],
            email: [
                { type: "required", message: "Email is required" },
                { type: "pattern", message: "Please enter a valid email id." }
            ],
            mobileNumber: [
                { type: "required", message: "Mobile No is required" },
                { type: "pattern", message: "Please enter a valid mobile no" }
            ],
            adress: [
                { type: "required", message: "Address is required" },
                { type: "maxlength", message: "Address can not be more than 100 charecter" }
            ],
            fromPlace: [
                { type: "required", message: "Place is required" },
                { type: "maxlength", message: "Place can not be more than 100 charecter" }
            ],
            company: [
                { type: "required", message: "Company is required" },
                { type: "maxlength", message: "Place can not be more than 100 charecter" }
            ],
            personVisitingInRWS: [
                { type: "required", message: "Person's name to be visited in RWS is required" },
                { type: "maxlength", message: "Place can not be more than 100 charecter" }
            ]
        };
        this.form = this.formBuilder.group({
            visitorName: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].maxLength(100)]],
            email: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].email]],
            mobileNumber: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].pattern("[0-9]{10}")]],
            adress: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].maxLength(100)]],
            fromPlace: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].maxLength(100)]],
            company: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].maxLength(100)]],
            personInSdl: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["Validators"].maxLength(100)]]
        });
        this.signaturePadOptions = {
            'maxwidth': 1,
            'minWidth': 1,
            'canvasWidth': 330,
            'canvasHeight': 230
        };
        this.isEmployeeDropDownVisible = false;
        this.visitor = new _models_visitor__WEBPACK_IMPORTED_MODULE_3__["Visitor"]();
        this.selectedUser = new _models_user__WEBPACK_IMPORTED_MODULE_14__["User"]();
        this.visitorService.observableUserList.subscribe(users => {
            this.usersList = users;
        });
    }
    //#region properties
    get visitorName() {
        return this.form.get("visitorName");
    }
    get email() {
        return this.form.get("email");
    }
    get mobileNumber() {
        return this.form.get("mobileNumber");
    }
    get adress() {
        return this.form.get("adress");
    }
    get fromPlace() {
        return this.form.get("fromPlace");
    }
    get company() {
        return this.form.get("company");
    }
    get personInSdl() {
        return this.form.get("personInSdl");
    }
    //#region methords
    drawStart() { }
    drawComplete() {
        // will be notified of szimek/signature_pad's onEnd event
        this.signatureImage = this.signaturePad.toDataURL();
        this.visitor.signature = this.signatureImage;
    }
    hideImage() {
        this.signatureMaskHidden = true;
    }
    /*
      drawClear(form:NgForm):void
      {
        this.signaturePad.clear();
        this.signatureMaskHidden = false;
      }*/
    resetForm(form) {
        this.signatureMaskHidden = false;
        this.signaturePad.clear();
        this.photoService.photos.pop();
        if (form != null)
            form.reset();
    }
    getCamera() {
        this.camera.getPicture({
            sourceType: this.camera.PictureSourceType.CAMERA,
            destinationType: this.camera.DestinationType.FILE_URI
        }).then((res) => { }).catch(e => { });
    }
    ngOnInit() {
        this.visitorService.getVisitorDetails(_models_settings__WEBPACK_IMPORTED_MODULE_11__["settings"].rootURL, _models_settings__WEBPACK_IMPORTED_MODULE_11__["settings"].token, _models_settings__WEBPACK_IMPORTED_MODULE_11__["settings"].userId);
        this.userName = _models_settings__WEBPACK_IMPORTED_MODULE_11__["settings"].userName;
        this.visitorService.getRWSUsers(_models_settings__WEBPACK_IMPORTED_MODULE_11__["settings"].rootURL);
    }
    ngOnDestroy() { }
    ngAfterViewInit() { }
    opencamera() {
        this.photoService.photos.pop();
        this.photoService.addNewToGallery();
    }
    onSubmit(form) {
        if (this.signatureImage == undefined) {
            this.showAlert("Please take a signature");
        }
        else {
            if (this.photos.length > 0) {
                var signatureString = this.signatureImage.replace("data:image/png;base64,", "");
                this.getBase64ImageFromURL(this.photos[0].webviewPath).subscribe(base64data => {
                    this.loadingControl.present();
                    this.visitorService.postVisitorDetails(form.value, signatureString, base64data, _models_settings__WEBPACK_IMPORTED_MODULE_11__["settings"].rootURL, _models_settings__WEBPACK_IMPORTED_MODULE_11__["settings"].token, _models_settings__WEBPACK_IMPORTED_MODULE_11__["settings"].userId).subscribe(res => {
                        this.resetForm(form);
                        var details = res;
                        this.visitorService.selectedVisitor = details;
                        this.loadingControl.dismiss();
                        this.openModal();
                    }, err => { console.log(err); });
                });
            }
            else {
                this.showAlert("Please take a photo");
            }
        }
    }
    getBase64ImageFromURL(url) {
        return rxjs__WEBPACK_IMPORTED_MODULE_10__["Observable"].create((observer) => {
            let img = new Image();
            img.crossOrigin = 'Anonymous';
            img.src = url;
            if (!img.complete) {
                img.onload = () => {
                    observer.next(this.getBase64Image(img));
                    observer.complete();
                };
                img.onerror = (err) => {
                    observer.error(err);
                };
            }
            else {
                observer.next(this.getBase64Image(img));
                observer.complete();
            }
        });
    }
    getBase64Image(img) {
        var canvas = document.createElement("canvas");
        canvas.width = img.width;
        canvas.height = img.height;
        var ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0);
        var dataURL = canvas.toDataURL("image/png");
        return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
    }
    showAlert(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: "Validation Failed!!",
                message: message,
                buttons: ['OK']
            }).then(response => response.present());
        });
    }
    downloadPDF() {
        const div = document.getElementById("div1");
        var option = {
            margin: 1,
            filename: Date.now().toString() + ".pdf"
        };
        try {
            html2pdf().set(option).from(div).save();
        }
        catch (e) { }
    }
    segmentChanged(event) {
        if (event.detail.value == "true") {
            this.isEmployee = true;
            this.isEmployeeDropDownVisible = false;
            this.selectedUser = new _models_user__WEBPACK_IMPORTED_MODULE_14__["User"]();
        }
        else {
            this.isEmployee = false;
        }
        //console.log(this.isEmployee);
    }
    openModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _modals_visitor_details_visitor_details_page__WEBPACK_IMPORTED_MODULE_12__["VisitorDetailsPage"],
                componentProps: {}
            });
            modal.onDidDismiss().then((dataReturned) => {
                if (dataReturned !== null) {
                    //this.dataReturned = dataReturned.data;
                    //alert('Modal Sent Data :'+ dataReturned);
                }
            });
            return yield modal.present();
        });
    }
    openSelectUser() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _modals_searchuser_searchuser_page__WEBPACK_IMPORTED_MODULE_13__["SearchuserPage"],
                componentProps: {}
            });
            modal.onDidDismiss().then((dataReturned) => {
                if (dataReturned !== null) {
                    //this.dataReturned = dataReturned.data;
                    //alert('Modal Sent Data :'+ dataReturned);
                }
            });
            return yield modal.present();
        });
    }
    //#endregion  
    loginUser() {
        this.loadingControl.present();
        var visitorUser = new _models_visitor__WEBPACK_IMPORTED_MODULE_3__["Visitor"];
        visitorUser.visitorId = undefined;
        visitorUser.visitorName = this.selectedUser.displayName;
        visitorUser.email = this.selectedUser.email;
        visitorUser.mobileNumber = Number("0000000000");
        visitorUser.adress = "RWS";
        visitorUser.fromPlace = "N/A";
        visitorUser.company = "RWS";
        visitorUser.signature = "None";
        visitorUser.picture = "None";
        visitorUser.loginDateTime = undefined;
        visitorUser.logoutDateTime = undefined;
        visitorUser.personInSdl = "N/A";
        this.visitorService.postVisitorDetails(visitorUser, "None", "None", _models_settings__WEBPACK_IMPORTED_MODULE_11__["settings"].rootURL, _models_settings__WEBPACK_IMPORTED_MODULE_11__["settings"].token, _models_settings__WEBPACK_IMPORTED_MODULE_11__["settings"].userId).subscribe(res => {
            var details = res;
            this.visitorService.selectedVisitor = details;
            this.isEmployeeDropDownVisible = false;
            this.selectedUser = new _models_user__WEBPACK_IMPORTED_MODULE_14__["User"]();
            this.loadingControl.dismiss();
            this.openModal();
        }, err => { console.log(err); });
    }
    selectVal(user) {
        this.selectedUser = user;
        this.isEmployeeDropDownVisible = false;
        console.log(this.selectedUser);
    }
    filterUserData(event) {
        this.usersList = this.visitorService.allUserList;
        this.selectedUser = new _models_user__WEBPACK_IMPORTED_MODULE_14__["User"];
        const val = event.target.value;
        if (val && val.trim() != '' && val.length > 0) {
            this.isEmployeeDropDownVisible = true;
            this.usersList = this.usersList.filter((item) => {
                return (item.displayName.toLowerCase().indexOf(val.toLowerCase()) > -1);
            });
        }
        else {
            this.isEmployeeDropDownVisible = false;
        }
    }
};
VisitorDetailsTabPage.ctorParameters = () => [
    { type: _services_visitorsdetails_service__WEBPACK_IMPORTED_MODULE_2__["VisitorsdetailsService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClient"] },
    { type: _services_photo_service__WEBPACK_IMPORTED_MODULE_4__["PhotoService"] },
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_5__["Camera"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavParams"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["PopoverController"] },
    { type: _services_loading_service__WEBPACK_IMPORTED_MODULE_15__["LoadingService"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('signatureCanvas', { static: true })
], VisitorDetailsTabPage.prototype, "signaturePad", void 0);
VisitorDetailsTabPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-visitorDetailsTab',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./visitorDetailsTab.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/visitorDetailsTab/visitorDetailsTab.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./visitorDetailsTab.page.scss */ "./src/app/visitorDetailsTab/visitorDetailsTab.page.scss")).default]
    })
], VisitorDetailsTabPage);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _ionic_pwa_elements_loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/pwa-elements/loader */ "./node_modules/@ionic/pwa-elements/loader/index.es2017.mjs");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");



Object(_ionic_pwa_elements_loader__WEBPACK_IMPORTED_MODULE_2__["defineCustomElements"])(window);


if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/suprabhatpaul/Git/Root/Ionic/VisitorBook/App/dailyVisitors/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map
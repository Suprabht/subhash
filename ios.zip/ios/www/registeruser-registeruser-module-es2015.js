(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["registeruser-registeruser-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/registeruser/registeruser.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/registeruser/registeruser.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n  <div class=\"topHeader\">\n    <div class=\"logoDiv\">\n      <img src=\"../../assets/logo.svg\" alt=\"RWS.com\" />\n    </div>\n  </div>\n  <div class=\"ion-content\">\n    <ion-card class=\"card-center\" >\n      <ion-card-content>\n        <div class=\"registerUserDiv\">\n            <div class=\"personName\">\n              <ion-item>\n                <ion-label color=\"primary\" position =\"floating\">Name</ion-label>\n                <ion-input inputmode=\"text\" required name=\"\" [(ngModel)]=\"this.registeruserService.userName\" (input)=\"this.registeruserService.checkName()\" (ionBlur)=\"this.registeruserService.checkName()\"></ion-input>\n              </ion-item>\n            </div>\n            <div class=\"personNameSearch\">\n              <ion-button (click)=\"this.registeruserService.openSelectUser()\"> <ion-icon name=\"search-outline\"></ion-icon>\n                &nbsp;&nbsp;Search RWS User</ion-button>\n            </div>\n            <ion-item>\n              <ion-label color=\"primary\" position =\"floating\">Email</ion-label>\n              <ion-input inputmode=\"text\" required name=\"\" [(ngModel)]=\"this.registeruserService.email\"></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-label color=\"primary\" position =\"floating\">Password</ion-label>\n              <ion-input inputmode=\"password\" type=\"password\" required name=\"\" [(ngModel)]=\"this.registeruserService.password\"></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-label color=\"primary\" position =\"floating\">Confirm Password</ion-label>\n              <ion-input inputmode=\"password\" type=\"password\"required name=\"\" [(ngModel)]=\"this.registeruserService.confirmPassword\"></ion-input>\n            </ion-item><br/>\n            <ion-item >\n              <ion-label color=\"primary\" >Select: Your office</ion-label>\n              <ion-select [(value)]=\"this.registeruserService.officeId\">\n                <ion-select-option *ngFor=\"let office of this.registeruserService.allOffice\" [value]=\"office.officeId\"><ion-text color=\"primary\">{{office.officeName}}</ion-text></ion-select-option>\n              </ion-select>\n            </ion-item>\n            <br/>\n            <ion-text color=\"danger\">\n              {{this.registeruserService.errorMessage}}\n            </ion-text>\n            <div class=\"registerUserButton\">\n              <ion-button color=\"tertiary\" (click) =\"registeruser()\" >\n                <ion-icon name=\"people-outline\"></ion-icon>&nbsp;&nbsp;Register User\n              </ion-button>\n            </div>\n          \n          <br/><br/>\n        </div>\n      </ion-card-content>\n    </ion-card>\n    <div class=\"footer\">\n      Designed and maintained by Solution Delivery. <a href=\"/auth\">Login</a>\n    </div>\n \n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/registeruser/registeruser-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/registeruser/registeruser-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: RegisteruserPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisteruserPageRoutingModule", function() { return RegisteruserPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _registeruser_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./registeruser.page */ "./src/app/registeruser/registeruser.page.ts");




const routes = [
    {
        path: '',
        component: _registeruser_page__WEBPACK_IMPORTED_MODULE_3__["RegisteruserPage"]
    }
];
let RegisteruserPageRoutingModule = class RegisteruserPageRoutingModule {
};
RegisteruserPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RegisteruserPageRoutingModule);



/***/ }),

/***/ "./src/app/registeruser/registeruser.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/registeruser/registeruser.module.ts ***!
  \*****************************************************/
/*! exports provided: RegisteruserPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisteruserPageModule", function() { return RegisteruserPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _registeruser_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./registeruser-routing.module */ "./src/app/registeruser/registeruser-routing.module.ts");
/* harmony import */ var _registeruser_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./registeruser.page */ "./src/app/registeruser/registeruser.page.ts");







let RegisteruserPageModule = class RegisteruserPageModule {
};
RegisteruserPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _registeruser_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegisteruserPageRoutingModule"]
        ],
        declarations: [_registeruser_page__WEBPACK_IMPORTED_MODULE_6__["RegisteruserPage"]]
    })
], RegisteruserPageModule);



/***/ }),

/***/ "./src/app/registeruser/registeruser.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/registeruser/registeruser.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".topHeader {\n  width: 100%;\n  height: 50px;\n}\n.topHeader .logoDiv {\n  /* width: 100%; */\n  /* max-width: 4.75rem; */\n  margin-left: 30px;\n  /* padding-top: 0.4rem; */\n  width: 80px;\n}\n.ion-content {\n  display: block;\n  background-image: url('loginBackground.jpg');\n  background-repeat: no-repeat;\n  width: 100%;\n  height: calc(100% - 60px);\n}\n.ion-content .card-center {\n  transform: translateX(-50%) translateY(-50%);\n  /*top: 45%;*/\n  top: 480px;\n  left: 50%;\n  position: absolute;\n}\n.ion-content .card-center .registerUserDiv {\n  width: 450px;\n}\n.ion-content .card-center .registerUserDiv .personName {\n  width: calc(100% - 185px);\n  display: inline-block;\n}\n.ion-content .card-center .registerUserDiv .personNameSearch {\n  display: inline-block;\n  width: 185px;\n}\n.ion-content .card-center .registerUserDiv .registerUserButton {\n  float: right;\n}\n.ion-content .footer {\n  width: calc(100% - 20px);\n  border-top: #D0D0D0 1px solid;\n  position: absolute;\n  bottom: 0px;\n  padding: 10px;\n  text-align: right;\n  color: #606060;\n  margin: 10px;\n  font-style: italic;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zdXByYWJoYXRwYXVsL0dpdC9Sb290L0lvbmljL1Zpc2l0b3JCb29rL0FwcC9kYWlseVZpc2l0b3JzL3NyYy9hcHAvcmVnaXN0ZXJ1c2VyL3JlZ2lzdGVydXNlci5wYWdlLnNjc3MiLCJzcmMvYXBwL3JlZ2lzdGVydXNlci9yZWdpc3RlcnVzZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUNDSjtBREFJO0VBQ0ksaUJBQUE7RUFDQSx3QkFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0FDRVI7QURDQTtFQUNJLGNBQUE7RUFDQSw0Q0FBQTtFQUNBLDRCQUFBO0VBQ0EsV0FBQTtFQUNBLHlCQUFBO0FDRUo7QURESTtFQUNJLDRDQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7QUNHUjtBREZRO0VBQ0ksWUFBQTtBQ0laO0FESFk7RUFDSSx5QkFBQTtFQUNBLHFCQUFBO0FDS2hCO0FESFk7RUFDSSxxQkFBQTtFQUNBLFlBQUE7QUNLaEI7QURIWTtFQUNJLFlBQUE7QUNLaEI7QURESTtFQUNJLHdCQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FDR1IiLCJmaWxlIjoic3JjL2FwcC9yZWdpc3RlcnVzZXIvcmVnaXN0ZXJ1c2VyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b3BIZWFkZXJ7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIC5sb2dvRGl2IHtcbiAgICAgICAgLyogd2lkdGg6IDEwMCU7ICovXG4gICAgICAgIC8qIG1heC13aWR0aDogNC43NXJlbTsgKi9cbiAgICAgICAgbWFyZ2luLWxlZnQ6IDMwcHg7XG4gICAgICAgIC8qIHBhZGRpbmctdG9wOiAwLjRyZW07ICovXG4gICAgICAgIHdpZHRoOiA4MHB4O1xuICAgIH1cbn1cbi5pb24tY29udGVudHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi4vLi4vYXNzZXRzL2xvZ2luQmFja2dyb3VuZC5qcGcpO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiBjYWxjKDEwMCUgLSA2MHB4KTtcbiAgICAuY2FyZC1jZW50ZXJ7XG4gICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKSB0cmFuc2xhdGVZKC01MCUpO1xuICAgICAgICAvKnRvcDogNDUlOyovXG4gICAgICAgIHRvcDo0ODBweDtcbiAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIC5yZWdpc3RlclVzZXJEaXZ7XG4gICAgICAgICAgICB3aWR0aDogNDUwcHg7XG4gICAgICAgICAgICAucGVyc29uTmFtZXtcbiAgICAgICAgICAgICAgICB3aWR0aDogY2FsYygxMDAlIC0gMTg1cHgpO1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC5wZXJzb25OYW1lU2VhcmNoe1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgICAgICAgICAgICB3aWR0aDogMTg1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAucmVnaXN0ZXJVc2VyQnV0dG9ue1xuICAgICAgICAgICAgICAgIGZsb2F0OiByaWdodDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICAuZm9vdGVye1xuICAgICAgICB3aWR0aDpjYWxjKDEwMCUgLSAyMHB4KTtcbiAgICAgICAgYm9yZGVyLXRvcDogI0QwRDBEMCAxcHggc29saWQ7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgYm90dG9tOiAwcHg7XG4gICAgICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgICAgICBjb2xvcjogIzYwNjA2MDtcbiAgICAgICAgbWFyZ2luOiAxMHB4O1xuICAgICAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgfVxufSIsIi50b3BIZWFkZXIge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA1MHB4O1xufVxuLnRvcEhlYWRlciAubG9nb0RpdiB7XG4gIC8qIHdpZHRoOiAxMDAlOyAqL1xuICAvKiBtYXgtd2lkdGg6IDQuNzVyZW07ICovXG4gIG1hcmdpbi1sZWZ0OiAzMHB4O1xuICAvKiBwYWRkaW5nLXRvcDogMC40cmVtOyAqL1xuICB3aWR0aDogODBweDtcbn1cblxuLmlvbi1jb250ZW50IHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLi8uLi9hc3NldHMvbG9naW5CYWNrZ3JvdW5kLmpwZyk7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDYwcHgpO1xufVxuLmlvbi1jb250ZW50IC5jYXJkLWNlbnRlciB7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKSB0cmFuc2xhdGVZKC01MCUpO1xuICAvKnRvcDogNDUlOyovXG4gIHRvcDogNDgwcHg7XG4gIGxlZnQ6IDUwJTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xufVxuLmlvbi1jb250ZW50IC5jYXJkLWNlbnRlciAucmVnaXN0ZXJVc2VyRGl2IHtcbiAgd2lkdGg6IDQ1MHB4O1xufVxuLmlvbi1jb250ZW50IC5jYXJkLWNlbnRlciAucmVnaXN0ZXJVc2VyRGl2IC5wZXJzb25OYW1lIHtcbiAgd2lkdGg6IGNhbGMoMTAwJSAtIDE4NXB4KTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuLmlvbi1jb250ZW50IC5jYXJkLWNlbnRlciAucmVnaXN0ZXJVc2VyRGl2IC5wZXJzb25OYW1lU2VhcmNoIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogMTg1cHg7XG59XG4uaW9uLWNvbnRlbnQgLmNhcmQtY2VudGVyIC5yZWdpc3RlclVzZXJEaXYgLnJlZ2lzdGVyVXNlckJ1dHRvbiB7XG4gIGZsb2F0OiByaWdodDtcbn1cbi5pb24tY29udGVudCAuZm9vdGVyIHtcbiAgd2lkdGg6IGNhbGMoMTAwJSAtIDIwcHgpO1xuICBib3JkZXItdG9wOiAjRDBEMEQwIDFweCBzb2xpZDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDBweDtcbiAgcGFkZGluZzogMTBweDtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIGNvbG9yOiAjNjA2MDYwO1xuICBtYXJnaW46IDEwcHg7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbn0iXX0= */");

/***/ }),

/***/ "./src/app/registeruser/registeruser.page.ts":
/*!***************************************************!*\
  !*** ./src/app/registeruser/registeruser.page.ts ***!
  \***************************************************/
/*! exports provided: RegisteruserPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisteruserPage", function() { return RegisteruserPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _models_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/settings */ "./src/app/models/settings.ts");
/* harmony import */ var _services_visitorsdetails_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/visitorsdetails.service */ "./src/app/services/visitorsdetails.service.ts");
/* harmony import */ var _registeruser_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./registeruser.service */ "./src/app/registeruser/registeruser.service.ts");





let RegisteruserPage = class RegisteruserPage {
    constructor(registeruserService, visitorService) {
        this.registeruserService = registeruserService;
        this.visitorService = visitorService;
    }
    ngOnInit() {
        this.registeruserService.getUsersDisplayName(_models_settings__WEBPACK_IMPORTED_MODULE_2__["settings"].rootURL);
        this.registeruserService.getOfficeName(_models_settings__WEBPACK_IMPORTED_MODULE_2__["settings"].rootURL);
        this.visitorService.getRWSUsers(_models_settings__WEBPACK_IMPORTED_MODULE_2__["settings"].rootURL);
    }
    registeruser() {
        this.registeruserService.registeruser(_models_settings__WEBPACK_IMPORTED_MODULE_2__["settings"].rootURL);
    }
};
RegisteruserPage.ctorParameters = () => [
    { type: _registeruser_service__WEBPACK_IMPORTED_MODULE_4__["RegisteruserService"] },
    { type: _services_visitorsdetails_service__WEBPACK_IMPORTED_MODULE_3__["VisitorsdetailsService"] }
];
RegisteruserPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-registeruser',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./registeruser.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/registeruser/registeruser.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./registeruser.page.scss */ "./src/app/registeruser/registeruser.page.scss")).default]
    })
], RegisteruserPage);



/***/ }),

/***/ "./src/app/registeruser/registeruser.service.ts":
/*!******************************************************!*\
  !*** ./src/app/registeruser/registeruser.service.ts ***!
  \******************************************************/
/*! exports provided: RegisteruserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisteruserService", function() { return RegisteruserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/loading.service */ "./src/app/services/loading.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _modals_searchuser_searchuser_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../modals/searchuser/searchuser.page */ "./src/app/modals/searchuser/searchuser.page.ts");







let RegisteruserService = class RegisteruserService {
    constructor(http, router, modalController, loadingControl) {
        this.http = http;
        this.router = router;
        this.modalController = modalController;
        this.loadingControl = loadingControl;
        this.userName = "";
        this.email = "";
        this.password = "";
        this.confirmPassword = "";
        this.errorMessage = "";
    }
    registeruser(rootURL) {
        if (this.userName.trim().length > 2) {
            if (this.allUserDisplayName.some(names => names.toLocaleLowerCase() === this.userName.toLocaleLowerCase())) {
                this.errorMessage = "Please choose another name. This name already exists.";
            }
            else {
                if ((this.password != "") && (this.confirmPassword != "") && (this.email != "") && (this.userName != "")) {
                    if (this.validateEmail(this.email)) {
                        if (this.confirmPassword == this.password) {
                            if (this.validatePassword(this.password)) {
                                var registerModel = {
                                    "email": this.email,
                                    "userName": this.userName,
                                    "password": this.password,
                                    "officeId": this.officeId
                                };
                                debugger;
                                this.http.post(rootURL + '/Authentication/Register', registerModel).subscribe((resp) => {
                                    if (resp.result == "Error") {
                                        this.errorMessage = resp.massage;
                                    }
                                    else {
                                        this.router.navigateByUrl('/auth');
                                    }
                                }, (error) => {
                                    this.errorMessage = error.error.massage;
                                });
                            }
                            else {
                                this.errorMessage = "Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character";
                            }
                        }
                        else {
                            this.errorMessage = "Confirm password and Password doesnot match.";
                        }
                    }
                    else {
                        this.errorMessage = "Please check the email Id.";
                    }
                }
                else {
                    this.errorMessage = "All fields are mandatory please enter name, email id and passwords.";
                }
            }
        }
        else {
            this.errorMessage = "User name should be greater than 4 characters.";
        }
    }
    checkName() {
        if (this.userName.trim().length > 4) {
            if (this.allUserDisplayName.some(names => names.toLocaleLowerCase() === this.userName.toLocaleLowerCase())) {
                this.errorMessage = "Please choose another name. This name already exists.";
            }
            else {
                this.errorMessage = "";
            }
        }
        else {
            this.errorMessage = "User name should be greater than 4 characters.";
        }
    }
    getUsersDisplayName(rootURL) {
        this.loadingControl.present();
        this.http.get(rootURL + '/Users/GetUsersDisplayName').subscribe((response) => {
            this.allUserDisplayName = response;
            this.loadingControl.dismiss();
            return this.allUserDisplayName;
        });
        return this.allUserDisplayName;
    }
    getOfficeName(rootURL) {
        //this.loadingControl.present();
        this.http.get(rootURL + '/Users/GetOffice').subscribe((response) => {
            this.allOffice = response;
            this.officeId = this.allOffice[0].officeId;
            // this.loadingControl.dismiss();
            return this.allOffice;
        });
        return this.allOffice;
    }
    validatePassword(password) {
        //Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character
        if (/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password)) {
            return (true);
        }
        return (false);
    }
    validateEmail(mail) {
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
            return (true);
        }
        return (false);
    }
    openSelectUser() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _modals_searchuser_searchuser_page__WEBPACK_IMPORTED_MODULE_6__["SearchuserPage"],
                componentProps: {}
            });
            modal.onDidDismiss().then((dataReturned) => {
                if (dataReturned !== null) {
                    var x = dataReturned.data;
                    console.log(dataReturned);
                    this.userName = x.identityName;
                    this.email = x.email;
                    this.officeId = x.officeId;
                    //this.dataReturned = dataReturned.data;
                    //alert('Modal Sent Data :'+ dataReturned);
                }
            });
            return yield modal.present();
        });
    }
};
RegisteruserService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _services_loading_service__WEBPACK_IMPORTED_MODULE_4__["LoadingService"] }
];
RegisteruserService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], RegisteruserService);



/***/ })

}]);
//# sourceMappingURL=registeruser-registeruser-module-es2015.js.map
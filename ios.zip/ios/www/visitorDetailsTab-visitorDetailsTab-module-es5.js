function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["visitorDetailsTab-visitorDetailsTab-module"], {
  /***/
  "./src/app/visitorDetailsTab/visitorDetailsTab-routing.module.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/visitorDetailsTab/visitorDetailsTab-routing.module.ts ***!
    \***********************************************************************/

  /*! exports provided: visitorDetailsTabPageRoutingModule */

  /***/
  function srcAppVisitorDetailsTabVisitorDetailsTabRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "visitorDetailsTabPageRoutingModule", function () {
      return visitorDetailsTabPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _visitorDetailsTab_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./visitorDetailsTab.page */
    "./src/app/visitorDetailsTab/visitorDetailsTab.page.ts");

    var routes = [{
      path: '',
      component: _visitorDetailsTab_page__WEBPACK_IMPORTED_MODULE_3__["VisitorDetailsTabPage"]
    }];

    var visitorDetailsTabPageRoutingModule = function visitorDetailsTabPageRoutingModule() {
      _classCallCheck(this, visitorDetailsTabPageRoutingModule);
    };

    visitorDetailsTabPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], visitorDetailsTabPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/visitorDetailsTab/visitorDetailsTab.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/visitorDetailsTab/visitorDetailsTab.module.ts ***!
    \***************************************************************/

  /*! exports provided: VisitorDetailsTabPageModule */

  /***/
  function srcAppVisitorDetailsTabVisitorDetailsTabModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VisitorDetailsTabPageModule", function () {
      return VisitorDetailsTabPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _visitorDetailsTab_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./visitorDetailsTab.page */
    "./src/app/visitorDetailsTab/visitorDetailsTab.page.ts");
    /* harmony import */


    var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../explore-container/explore-container.module */
    "./src/app/explore-container/explore-container.module.ts");
    /* harmony import */


    var angular2_signaturepad__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! angular2-signaturepad */
    "./node_modules/angular2-signaturepad/__ivy_ngcc__/index.js");
    /* harmony import */


    var angular2_signaturepad__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(angular2_signaturepad__WEBPACK_IMPORTED_MODULE_7__);
    /* harmony import */


    var _visitorDetailsTab_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./visitorDetailsTab-routing.module */
    "./src/app/visitorDetailsTab/visitorDetailsTab-routing.module.ts");

    var VisitorDetailsTabPageModule = function VisitorDetailsTabPageModule() {
      _classCallCheck(this, VisitorDetailsTabPageModule);
    };

    VisitorDetailsTabPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
      imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_6__["ExploreContainerComponentModule"], _visitorDetailsTab_routing_module__WEBPACK_IMPORTED_MODULE_8__["visitorDetailsTabPageRoutingModule"], angular2_signaturepad__WEBPACK_IMPORTED_MODULE_7__["SignaturePadModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"]],
      declarations: [_visitorDetailsTab_page__WEBPACK_IMPORTED_MODULE_5__["VisitorDetailsTabPage"]]
    })], VisitorDetailsTabPageModule);
    /***/
  }
}]);
//# sourceMappingURL=visitorDetailsTab-visitorDetailsTab-module-es5.js.map
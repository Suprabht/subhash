(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["reportsTab-reportsTab-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/reportsTab/reportsTab.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/reportsTab/reportsTab.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"success\">\n    <ion-buttons>\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>\n      Reports ({{this.userName}})\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-fab horizontal=\"end\" vertical=\"top\" slot=\"fixed\" edge>\n    <ion-fab-button *ngIf=\"this.visitorService.fetchingAllRecords\" color=\"danger\">\n      <ion-icon name=\"hourglass-outline\"></ion-icon>\n    </ion-fab-button>\n    <ion-fab-button *ngIf=\"!this.visitorService.fetchingAllRecords\" color=\"secondary\" (click)=\"refresh()\">\n      <ion-icon name=\"sync-outline\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <ion-card>\n    <ion-card-content>\n\n      <div class=\"leftDiv\">\n        <ion-card>\n          <ion-card-content>\n\n            <ion-item>\n              <ion-label color=\"primary\" position=\"floating\">Visitors name</ion-label>\n              <ion-input autocapitalize inputmode=\"text\" [(ngModel)]=\"this.visitor.visitorName\"\n                (input)=\"keyPressSearch($event,'visitorName')\"></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-label color=\"primary\" position=\"floating\">Email</ion-label>\n              <ion-input autocapitalize inputmode=\"text\" [(ngModel)]=\"this.visitor.email\"\n                (input)=\"keyPressSearch($event,'email')\"></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-label color=\"primary\" position=\"floating\">Mobile</ion-label>\n              <ion-input autocapitalize inputmode=\"text\" [(ngModel)]=\"this.visitor.mobileNumber\"\n                (input)=\"keyPressSearch($event,'mobileNumber')\"></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-label color=\"primary\" position=\"floating\">Check In Date</ion-label>\n              <ion-input autocapitalize inputmode=\"text\" [(ngModel)]=\"this.visitor.loginDateTime\"\n                (input)=\"keyPressSearch($event,'loginDateTime')\"></ion-input>\n            </ion-item>\n\n          </ion-card-content>\n        </ion-card>\n      </div>\n      <div class=\"rightDiv\">\n        <ion-card>\n          <ion-card-content>\n\n            <ion-item>\n              <ion-label color=\"primary\" position=\"floating\">From Place Name</ion-label>\n              <ion-input autocapitalize inputmode=\"text\" [(ngModel)]=\"this.visitor.fromPlace\"\n                (input)=\"keyPressSearch($event,'fromPlace')\"></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-label color=\"primary\" position=\"floating\">Company</ion-label>\n              <ion-input autocapitalize inputmode=\"text\" [(ngModel)]=\"this.visitor.company\"\n                (input)=\"keyPressSearch($event,'company')\"></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-label color=\"primary\" position=\"floating\">Person visiting in RWS</ion-label>\n              <ion-input autocapitalize inputmode=\"text\" [(ngModel)]=\"this.visitor.personInSdl\"\n                (input)=\"keyPressSearch($event,'personInSdl')\"></ion-input>\n            </ion-item>\n            <div class=\"buttons\">\n              <ion-button color=\"danger\" (click)=\"reset()\">\n                <ion-icon name=\"refresh-circle-outline\"></ion-icon>\n                &nbsp;&nbsp;Reset\n              </ion-button>\n              <ion-button color=\"tertiary\" type=\"submit\">\n                <ion-icon name=\"save-outline\"></ion-icon>\n                &nbsp;&nbsp;Submit\n              </ion-button>\n            </div>\n\n          </ion-card-content>\n        </ion-card>\n      </div>\n\n    </ion-card-content>\n  </ion-card>\n  <div class=\"reportingButton\">\n    <ion-button shape=\"round\" color=\"secondary\" (click)=\"downloadPDF()\">\n      <ion-icon name=\"print-outline\"></ion-icon>\n      &nbsp;&nbsp;PDF Download\n    </ion-button>\n    <ion-button shape=\"round\" color=\"success\" (click)=\"downloadExcel()\">\n      <ion-icon name=\"documents-outline\"></ion-icon>\n      &nbsp;&nbsp;CSV Download\n    </ion-button>\n    <ion-button shape=\"round\" color=\"tertiary\" (click)=\"emailReport(emailReport)\">\n      <ion-icon name=\"mail-outline\"></ion-icon>\n      &nbsp;&nbsp;Email Report\n    </ion-button>\n  </div>\n  <div class=\"listingDiv\">\n    <ion-card *ngFor=\"let detail of this.detailList\">\n      <div></div>\n      <ion-card-header>\n        <ion-card-subtitle>#{{detail.visitorId}}</ion-card-subtitle>\n        <ion-card-title>{{detail.visitorName}}</ion-card-title>\n      </ion-card-header>\n      <ion-card-content class=\"visitorDetailCardContent\">\n        <div class=\"visitorDetailContent\">\n          <ion-chip>\n            <ion-icon color=\"success\" name=\"mail\"></ion-icon>\n            <ion-label><a href=\"mailto:{{detail.email | lowercase}}\"\n                style=\"text-decoration: none; color:#000; cursor: pointer;\">{{detail.email | lowercase}}</a></ion-label>\n          </ion-chip>\n          <ion-chip>\n            <ion-icon color=\"success\" name=\"call\"></ion-icon>\n            <ion-label><a href=\"tel:{{detail.mobileNumber}}\"\n                style=\"text-decoration: none; color:#000; cursor: pointer;\">{{detail.mobileNumber}}</a></ion-label>\n          </ion-chip>\n          <ion-text color=\"secondary\">\n            <h1>\n              Address\n            </h1>\n          </ion-text>\n          <ion-icon color=\"primary\" name=\"home-outline\"></ion-icon>\n          <ion-text>&nbsp;{{detail.adress}}\n          </ion-text><br /><br />\n\n          <ion-icon color=\"primary\" name=\"location-outline\"></ion-icon>\n          <ion-text><strong>&nbsp;Coming From: </strong></ion-text>\n          <ion-text>{{detail.fromPlace}}</ion-text><br />\n\n          <ion-icon color=\"primary\" name=\"globe-outline\"></ion-icon>\n          <ion-text><strong>&nbsp;Company: </strong></ion-text>\n          <ion-text>{{detail.company}}</ion-text><br />\n\n          <ion-icon color=\"primary\" name=\"body-outline\"></ion-icon>\n          <ion-text><strong>&nbsp;Person visiting in RWS: </strong></ion-text>\n          <ion-text>{{detail.personInSdl}}</ion-text><br /><br />\n\n          <ion-icon color=\"primary\" name=\"log-in-outline\"></ion-icon>\n          <ion-text><strong>&nbsp;Check In Date and Time : </strong></ion-text>\n          <ion-text>{{detail.loginDateTime | date: \"yyyy/MM/dd HH:mm:ss\"}}</ion-text><br />\n          <ion-icon color=\"primary\" name=\"log-out-outline\"></ion-icon>\n          <ion-text><strong>&nbsp;Check Out Date and Time: </strong></ion-text>\n          <ion-text *ngIf=\"detail.logoutDateTime != undefined\">{{detail.logoutDateTime | date: \"yyyy/MM/dd HH:mm:ss\"}}\n          </ion-text>\n          <ion-text *ngIf=\"detail.logoutDateTime == undefined\">Still not logged out</ion-text><br /><br />\n\n          <ion-button shape=\"round\" color=\"secondary\" (click)=\"downloadPDFVisitorDetails(detail)\">\n            <ion-icon name=\"print-outline\"></ion-icon>\n          </ion-button>\n\n          <ion-button shape=\"round\" color=\"tertiary\" (click)=\"sendEmailOfVisitorDetails(detail.visitorId)\">\n            <ion-icon name=\"mail-outline\"></ion-icon>\n          </ion-button>\n        </div>\n      </ion-card-content>\n      <ion-card class=\"photoCard\">\n        <ion-card-header>\n          Photo\n        </ion-card-header>\n        <ion-card-content>\n          <img style=\"width:260px; height: 180px;\" src=\"{{this.imageUrl}}/{{detail.picture}}\" />\n        </ion-card-content>\n      </ion-card>\n      <ion-card class=\"photoSignature\">\n        <ion-card-header>\n          Signature\n        </ion-card-header>\n        <ion-card-content>\n          <img style=\"width:260px; height: 180px;\" src=\"{{this.imageUrl}}/{{detail.signature}}\" />\n        </ion-card-content>\n      </ion-card>\n    </ion-card>\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/reportsTab/reportsTab-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/reportsTab/reportsTab-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: ReportsTabPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportsTabPageRoutingModule", function() { return ReportsTabPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _reportsTab_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./reportsTab.page */ "./src/app/reportsTab/reportsTab.page.ts");




const routes = [
    {
        path: '',
        component: _reportsTab_page__WEBPACK_IMPORTED_MODULE_3__["ReportsTabPage"],
    }
];
let ReportsTabPageRoutingModule = class ReportsTabPageRoutingModule {
};
ReportsTabPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], ReportsTabPageRoutingModule);



/***/ }),

/***/ "./src/app/reportsTab/reportsTab.module.ts":
/*!*************************************************!*\
  !*** ./src/app/reportsTab/reportsTab.module.ts ***!
  \*************************************************/
/*! exports provided: ReportsTabPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportsTabPageModule", function() { return ReportsTabPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _reportsTab_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./reportsTab.page */ "./src/app/reportsTab/reportsTab.page.ts");
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../explore-container/explore-container.module */ "./src/app/explore-container/explore-container.module.ts");
/* harmony import */ var _reportsTab_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./reportsTab-routing.module */ "./src/app/reportsTab/reportsTab-routing.module.ts");









let ReportsTabPageModule = class ReportsTabPageModule {
};
ReportsTabPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
            _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_7__["ExploreContainerComponentModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _reportsTab_page__WEBPACK_IMPORTED_MODULE_6__["ReportsTabPage"] }]),
            _reportsTab_routing_module__WEBPACK_IMPORTED_MODULE_8__["ReportsTabPageRoutingModule"],
        ],
        declarations: [_reportsTab_page__WEBPACK_IMPORTED_MODULE_6__["ReportsTabPage"]]
    })
], ReportsTabPageModule);



/***/ }),

/***/ "./src/app/reportsTab/reportsTab.page.scss":
/*!*************************************************!*\
  !*** ./src/app/reportsTab/reportsTab.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".leftDiv {\n  float: left;\n  width: 50%;\n}\n\n.rightDiv {\n  float: right;\n  width: 50%;\n}\n\n.rightDiv .buttons {\n  float: right;\n  margin-top: 20px;\n  padding-bottom: 20px;\n}\n\n.reportingButton {\n  width: 100%;\n  text-align: right;\n  padding-right: 10px;\n}\n\n.listingDiv .visitorDetailCardContent {\n  float: left;\n  width: 50%;\n}\n\n.listingDiv .photoCard {\n  float: right;\n}\n\n.listingDiv .photoSignature {\n  float: right;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zdXByYWJoYXRwYXVsL0dpdC9Sb290L0lvbmljL1Zpc2l0b3JCb29rL0FwcC9kYWlseVZpc2l0b3JzL3NyYy9hcHAvcmVwb3J0c1RhYi9yZXBvcnRzVGFiLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcmVwb3J0c1RhYi9yZXBvcnRzVGFiLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxVQUFBO0FDQ0o7O0FEQ0E7RUFDSSxZQUFBO0VBQ0EsVUFBQTtBQ0VKOztBRERJO0VBQ0ksWUFBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7QUNHUjs7QURBQTtFQUNJLFdBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FDR0o7O0FEQUk7RUFDSSxXQUFBO0VBQ0EsVUFBQTtBQ0dSOztBRERRO0VBQ0ksWUFBQTtBQ0daOztBRERRO0VBQ0ksWUFBQTtBQ0daIiwiZmlsZSI6InNyYy9hcHAvcmVwb3J0c1RhYi9yZXBvcnRzVGFiLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sZWZ0RGl2e1xuICAgIGZsb2F0OiBsZWZ0O1xuICAgIHdpZHRoOiA1MCU7XG59XG4ucmlnaHREaXZ7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIHdpZHRoOiA1MCU7XG4gICAgLmJ1dHRvbnN7XG4gICAgICAgIGZsb2F0OiByaWdodDtcbiAgICAgICAgbWFyZ2luLXRvcDogMjBweDtcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDIwcHg7XG4gICAgfVxufVxuLnJlcG9ydGluZ0J1dHRvbntcbiAgICB3aWR0aDogMTAwJTtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xufVxuLmxpc3RpbmdEaXZ7XG4gICAgLnZpc2l0b3JEZXRhaWxDYXJkQ29udGVudHtcbiAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgIHdpZHRoOiA1MCU7XG4gICAgfVxuICAgICAgICAucGhvdG9DYXJke1xuICAgICAgICAgICAgZmxvYXQ6IHJpZ2h0O1xuICAgICAgICB9XG4gICAgICAgIC5waG90b1NpZ25hdHVyZXtcbiAgICAgICAgICAgIGZsb2F0OiByaWdodDtcbiAgICAgICAgfVxufSIsIi5sZWZ0RGl2IHtcbiAgZmxvYXQ6IGxlZnQ7XG4gIHdpZHRoOiA1MCU7XG59XG5cbi5yaWdodERpdiB7XG4gIGZsb2F0OiByaWdodDtcbiAgd2lkdGg6IDUwJTtcbn1cbi5yaWdodERpdiAuYnV0dG9ucyB7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLXRvcDogMjBweDtcbiAgcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbi5yZXBvcnRpbmdCdXR0b24ge1xuICB3aWR0aDogMTAwJTtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG59XG5cbi5saXN0aW5nRGl2IC52aXNpdG9yRGV0YWlsQ2FyZENvbnRlbnQge1xuICBmbG9hdDogbGVmdDtcbiAgd2lkdGg6IDUwJTtcbn1cbi5saXN0aW5nRGl2IC5waG90b0NhcmQge1xuICBmbG9hdDogcmlnaHQ7XG59XG4ubGlzdGluZ0RpdiAucGhvdG9TaWduYXR1cmUge1xuICBmbG9hdDogcmlnaHQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/reportsTab/reportsTab.page.ts":
/*!***********************************************!*\
  !*** ./src/app/reportsTab/reportsTab.page.ts ***!
  \***********************************************/
/*! exports provided: ReportsTabPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportsTabPage", function() { return ReportsTabPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _models_visitor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/visitor */ "./src/app/models/visitor.ts");
/* harmony import */ var _models_settings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/settings */ "./src/app/models/settings.ts");
/* harmony import */ var _services_visitorsdetails_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/visitorsdetails.service */ "./src/app/services/visitorsdetails.service.ts");





//import { CapacitordownloadService } from '../services/capacitordownload.service';
let ReportsTabPage = class ReportsTabPage {
    constructor(visitorService) {
        this.visitorService = visitorService;
        this.userName = "";
        this.visitor = new _models_visitor__WEBPACK_IMPORTED_MODULE_2__["Visitor"]();
        this.visitorService.observableVisitorList.subscribe(visitor => {
            //console.log("changed....");
            this.detailList = visitor;
        });
    }
    ngOnInit() {
        this.selectedVisitor = new _models_visitor__WEBPACK_IMPORTED_MODULE_2__["Visitor"]();
        //this.imageUrl = settings.rootURL.replace("/api","");
        this.imageUrl = _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].rootURL;
        if (!this.visitorService.fetchingAllRecords) {
            this.detailList = this.visitorService.getVisitorDetails(_models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].rootURL, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].token, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].userId);
        }
        this.userName = _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].userName;
    }
    keyPressSearch(event, controlName) {
        //console.log(event);
        this.detailList = this.visitorService.allVisitorList;
        var valueToTest = event.target.value.toLowerCase();
        if (controlName === "visitorName") {
            this.detailList = this.visitorService.allVisitorList.filter(visitor => visitor.visitorName.toLowerCase().includes(valueToTest));
        }
        if (controlName === "email") {
            this.detailList = this.visitorService.allVisitorList.filter(visitor => visitor.email.toLowerCase().includes(valueToTest));
        }
        if (controlName === "mobileNumber") {
            this.detailList = this.visitorService.allVisitorList.filter(visitor => visitor.mobileNumber.toLowerCase().includes(valueToTest));
        }
        if (controlName === "loginDateTime") {
            this.detailList = this.visitorService.allVisitorList.filter(visitor => visitor.loginDateTime.toLowerCase().includes(valueToTest));
        }
        if (controlName === "fromPlace") {
            this.detailList = this.visitorService.allVisitorList.filter(visitor => visitor.fromPlace.toLowerCase().includes(valueToTest));
        }
        if (controlName === "company") {
            this.detailList = this.visitorService.allVisitorList.filter(visitor => visitor.company.toLowerCase().includes(valueToTest));
        }
        if (controlName === "personVisitingInRWS") {
            this.detailList = this.visitorService.allVisitorList.filter(visitor => visitor.personVisitingInRWS.toLowerCase().includes(valueToTest));
        }
        //console.log(event, event.keyCode, event.keyIdentifier);
        //console.log(this.visitor);
        console.log(this.detailList.length);
    }
    reset() {
        this.visitor = new _models_visitor__WEBPACK_IMPORTED_MODULE_2__["Visitor"]();
        this.detailList = this.visitorService.allVisitorList;
    }
    submit() {
        this.detailList = this.visitorService.allVisitorList.filter(visitor => visitor.visitorName.toLowerCase().includes(this.visitor.visitorName) &&
            visitor.email.toLowerCase().includes(this.visitor.email) &&
            visitor.mobileNumber.toLowerCase().includes(this.visitor.mobileNumber) &&
            visitor.loginDateTime.toLowerCase().includes(this.visitor.loginDateTime) &&
            visitor.fromPlace.toLowerCase().includes(this.visitor.fromPlace) &&
            visitor.company.toLowerCase().includes(this.visitor.company) &&
            visitor.personInSdl.toLowerCase().includes(this.visitor.personInSdl));
    }
    refresh() {
        //this.capacitordownloadService.download();
        this.selectedVisitor = new _models_visitor__WEBPACK_IMPORTED_MODULE_2__["Visitor"]();
        if (!this.visitorService.fetchingAllRecords) {
            this.detailList = this.visitorService.getVisitorDetails(_models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].rootURL, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].token, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].userId);
        } /**/
    }
    sendEmailOfVisitorDetails(id) {
        //this.visitorService.sendEmailOfVisitorDetails(id, settings.rootURL);
        this.visitorService.sendEmailOfVisitorDetails(id, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].rootURL, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].userEmail, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].token).subscribe(response => {
            //this.detailList = response as Visitor[];
            console.log(response);
        });
    }
    downloadPDFVisitorDetails(visitor) {
        this.visitorService.downloadPDFVisitorDetails(visitor.visitorId, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].rootURL, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].token);
        /*this.visitorService.downloadPDFVisitorDetails(visitor.visitorId, settings.rootURL, settings.token).subscribe((data: Blob) => {
            var file = new Blob([data], { type: 'application/pdf' })
            var fileURL = URL.createObjectURL(file);
            // if you want to open PDF in new tab
            window.open(fileURL);
            var a         = document.createElement('a');
            a.href        = fileURL;
            //a.target      = '_blank';
            a.download    = 'visitorDetails_'+Date.now()+'.pdf';
            document.body.appendChild(a);
            a.click();
          },
          (error) => {
            console.log('getPDF error: ',error);
          }
        );*/
    }
    downloadExcel() {
        let visitorIds = new Array();
        this.detailList.forEach(element => {
            visitorIds.push(element.visitorId);
        });
        this.visitorService.downloadExcel(visitorIds, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].rootURL, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].token).subscribe((response) => {
            // @ts-ignore
            let file = new Blob([response], { type: 'text/csv' });
            let downloadUrl = URL.createObjectURL(file);
            let a = document.createElement('a');
            a.href = downloadUrl;
            a.download = 'report_' + Date.now() + '.csv'; // you can take a custom name as well as provide by server
            // start download
            a.click();
            // after certain amount of time remove this object!!!
            setTimeout(() => {
                URL.revokeObjectURL(downloadUrl);
            }, 100);
        });
    }
    downloadPDF() {
        let visitorIds = new Array();
        this.detailList.forEach(element => {
            visitorIds.push(element.visitorId);
        });
        this.visitorService.downloadPDF(visitorIds, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].rootURL, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].token).subscribe((response) => {
            // @ts-ignore
            let file = new Blob([response], { type: 'application/pdf' });
            let downloadUrl = URL.createObjectURL(file);
            let a = document.createElement('a');
            a.href = downloadUrl;
            a.download = 'reportPDF_' + Date.now() + '.pdf'; // you can take a custom name as well as provide by server
            // start download
            a.click();
            // after certain amount of time remove this object!!!
            setTimeout(() => {
                URL.revokeObjectURL(downloadUrl);
            }, 100);
        });
    }
    emailReport() {
        let visitorIds = new Array();
        this.detailList.forEach(element => {
            visitorIds.push(element.visitorId);
        });
        this.visitorService.emailReport(visitorIds, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].rootURL, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].userEmail, _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].token).subscribe(response => {
            console.log(response);
        });
    }
};
ReportsTabPage.ctorParameters = () => [
    { type: _services_visitorsdetails_service__WEBPACK_IMPORTED_MODULE_4__["VisitorsdetailsService"] }
];
ReportsTabPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-reportsTab',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./reportsTab.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/reportsTab/reportsTab.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./reportsTab.page.scss */ "./src/app/reportsTab/reportsTab.page.scss")).default]
    })
], ReportsTabPage);



/***/ })

}]);
//# sourceMappingURL=reportsTab-reportsTab-module-es2015.js.map
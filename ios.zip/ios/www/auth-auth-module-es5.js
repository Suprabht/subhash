function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["auth-auth-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth.page.html":
  /*!***************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth.page.html ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAuthAuthPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n<ion-content>\n  <div class=\"topHeader\">\n    <div class=\"logoDiv\">\n      <img src=\"../../assets/logo.svg\" alt=\"RWS.com\" />\n    </div>\n  </div>\n  <div class=\"ion-content\">\n    <ion-card class=\"card-center\" >\n      <ion-card-content>\n        <div class=\"loginDiv\">\n         \n            <ion-item>\n              <ion-label color=\"primary\" position =\"floating\">Email</ion-label>\n              <ion-input autocapitalize inputmode=\"text\" required name=\"\" [(ngModel)]=\"this.authService.userEmail\"></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-label color=\"primary\" position =\"floating\">Password</ion-label>\n              <ion-input autocapitalize inputmode=\"password\" type=\"password\"required name=\"\" [(ngModel)]=\"this.authService.userPassword\"></ion-input>\n            </ion-item><br/>\n            <ion-text color=\"danger\">\n              {{this.authService.errorMessage}}\n            </ion-text>\n            <div class=\"loginButton\">\n              <ion-button color=\"tertiary\" (click) =\"onLogin()\" >\n                <ion-icon name=\"log-in-outline\"></ion-icon>&nbsp;&nbsp;Login\n              </ion-button>\n            </div>\n          \n          <br/><br/>\n        </div>\n      </ion-card-content>\n    </ion-card>\n    <div class=\"footer\">\n      Designed and maintained by Solution Delivery. <a href=\"/registeruser\">Registration</a>\n    </div>\n  </div>\n  <div class=\"wellcomeText\">\n    <ion-text><h1>Welcome to RWS Visitor's book!</h1></ion-text>\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/auth/auth-routing.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/auth/auth-routing.module.ts ***!
    \*********************************************/

  /*! exports provided: AuthPageRoutingModule */

  /***/
  function srcAppAuthAuthRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthPageRoutingModule", function () {
      return AuthPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _auth_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./auth.page */
    "./src/app/auth/auth.page.ts");

    var routes = [{
      path: '',
      component: _auth_page__WEBPACK_IMPORTED_MODULE_3__["AuthPage"]
    }];

    var AuthPageRoutingModule = function AuthPageRoutingModule() {
      _classCallCheck(this, AuthPageRoutingModule);
    };

    AuthPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AuthPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/auth/auth.module.ts":
  /*!*************************************!*\
    !*** ./src/app/auth/auth.module.ts ***!
    \*************************************/

  /*! exports provided: AuthPageModule */

  /***/
  function srcAppAuthAuthModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthPageModule", function () {
      return AuthPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _auth_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./auth-routing.module */
    "./src/app/auth/auth-routing.module.ts");
    /* harmony import */


    var _auth_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./auth.page */
    "./src/app/auth/auth.page.ts");

    var AuthPageModule = function AuthPageModule() {
      _classCallCheck(this, AuthPageModule);
    };

    AuthPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _auth_routing_module__WEBPACK_IMPORTED_MODULE_5__["AuthPageRoutingModule"]],
      declarations: [_auth_page__WEBPACK_IMPORTED_MODULE_6__["AuthPage"]]
    })], AuthPageModule);
    /***/
  },

  /***/
  "./src/app/auth/auth.page.scss":
  /*!*************************************!*\
    !*** ./src/app/auth/auth.page.scss ***!
    \*************************************/

  /*! exports provided: default */

  /***/
  function srcAppAuthAuthPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".topHeader {\n  width: 100%;\n  height: 50px;\n}\n.topHeader .logoDiv {\n  /* width: 100%; */\n  /* max-width: 4.75rem; */\n  margin-left: 30px;\n  /* padding-top: 0.4rem; */\n  width: 80px;\n}\n.ion-content {\n  display: block;\n  background-image: url('loginBackground.jpg');\n  background-repeat: no-repeat;\n  width: 100%;\n  height: calc(100% - 60px);\n}\n.ion-content .card-center {\n  transform: translateX(-50%) translateY(-50%);\n  /*top: 45%;*/\n  top: 480px;\n  left: 50%;\n  position: absolute;\n}\n.ion-content .card-center .loginDiv {\n  width: 450px;\n}\n.ion-content .card-center .loginDiv .loginButton {\n  float: right;\n}\n.ion-content .footer {\n  width: calc(100% - 20px);\n  border-top: #D0D0D0 1px solid;\n  position: absolute;\n  bottom: 0px;\n  padding: 10px;\n  text-align: right;\n  color: #606060;\n  margin: 10px;\n  font-style: italic;\n}\n.wellcomeText {\n  top: 250px;\n  position: absolute;\n  width: 100%;\n  color: #fff;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zdXByYWJoYXRwYXVsL0dpdC9Sb290L0lvbmljL1Zpc2l0b3JCb29rL0FwcC9kYWlseVZpc2l0b3JzL3NyYy9hcHAvYXV0aC9hdXRoLnBhZ2Uuc2NzcyIsInNyYy9hcHAvYXV0aC9hdXRoLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0FDQ0o7QURBSTtFQUNJLGlCQUFBO0VBQ0Esd0JBQUE7RUFDQSxpQkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtBQ0VSO0FEQ0E7RUFDSSxjQUFBO0VBQ0EsNENBQUE7RUFDQSw0QkFBQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtBQ0VKO0FEREk7RUFDSSw0Q0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtFQUNBLGtCQUFBO0FDR1I7QURGUTtFQUNJLFlBQUE7QUNJWjtBREhZO0VBQ0ksWUFBQTtBQ0toQjtBRERJO0VBQ0ksd0JBQUE7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUNHUjtBREFBO0VBQ0ksVUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQ0dKIiwiZmlsZSI6InNyYy9hcHAvYXV0aC9hdXRoLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b3BIZWFkZXJ7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIC5sb2dvRGl2IHtcbiAgICAgICAgLyogd2lkdGg6IDEwMCU7ICovXG4gICAgICAgIC8qIG1heC13aWR0aDogNC43NXJlbTsgKi9cbiAgICAgICAgbWFyZ2luLWxlZnQ6IDMwcHg7XG4gICAgICAgIC8qIHBhZGRpbmctdG9wOiAwLjRyZW07ICovXG4gICAgICAgIHdpZHRoOiA4MHB4O1xuICAgIH1cbn1cbi5pb24tY29udGVudHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi4vLi4vYXNzZXRzL2xvZ2luQmFja2dyb3VuZC5qcGcpO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiBjYWxjKDEwMCUgLSA2MHB4KTtcbiAgICAuY2FyZC1jZW50ZXJ7XG4gICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKSB0cmFuc2xhdGVZKC01MCUpO1xuICAgICAgICAvKnRvcDogNDUlOyovXG4gICAgICAgIHRvcDo0ODBweDtcbiAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIC5sb2dpbkRpdntcbiAgICAgICAgICAgIHdpZHRoOiA0NTBweDtcbiAgICAgICAgICAgIC5sb2dpbkJ1dHRvbntcbiAgICAgICAgICAgICAgICBmbG9hdDogcmlnaHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgLmZvb3RlcntcbiAgICAgICAgd2lkdGg6Y2FsYygxMDAlIC0gMjBweCk7XG4gICAgICAgIGJvcmRlci10b3A6ICNEMEQwRDAgMXB4IHNvbGlkO1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIGJvdHRvbTogMHB4O1xuICAgICAgICBwYWRkaW5nOiAxMHB4O1xuICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICAgICAgY29sb3I6ICM2MDYwNjA7XG4gICAgICAgIG1hcmdpbjogMTBweDtcbiAgICAgICAgZm9udC1zdHlsZTogaXRhbGljO1xuICAgIH1cbn1cbi53ZWxsY29tZVRleHR7XG4gICAgdG9wOjI1MHB4O1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBjb2xvcjogI2ZmZjtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59IiwiLnRvcEhlYWRlciB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDUwcHg7XG59XG4udG9wSGVhZGVyIC5sb2dvRGl2IHtcbiAgLyogd2lkdGg6IDEwMCU7ICovXG4gIC8qIG1heC13aWR0aDogNC43NXJlbTsgKi9cbiAgbWFyZ2luLWxlZnQ6IDMwcHg7XG4gIC8qIHBhZGRpbmctdG9wOiAwLjRyZW07ICovXG4gIHdpZHRoOiA4MHB4O1xufVxuXG4uaW9uLWNvbnRlbnQge1xuICBkaXNwbGF5OiBibG9jaztcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKC4uLy4uL2Fzc2V0cy9sb2dpbkJhY2tncm91bmQuanBnKTtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogY2FsYygxMDAlIC0gNjBweCk7XG59XG4uaW9uLWNvbnRlbnQgLmNhcmQtY2VudGVyIHtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpIHRyYW5zbGF0ZVkoLTUwJSk7XG4gIC8qdG9wOiA0NSU7Ki9cbiAgdG9wOiA0ODBweDtcbiAgbGVmdDogNTAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG59XG4uaW9uLWNvbnRlbnQgLmNhcmQtY2VudGVyIC5sb2dpbkRpdiB7XG4gIHdpZHRoOiA0NTBweDtcbn1cbi5pb24tY29udGVudCAuY2FyZC1jZW50ZXIgLmxvZ2luRGl2IC5sb2dpbkJ1dHRvbiB7XG4gIGZsb2F0OiByaWdodDtcbn1cbi5pb24tY29udGVudCAuZm9vdGVyIHtcbiAgd2lkdGg6IGNhbGMoMTAwJSAtIDIwcHgpO1xuICBib3JkZXItdG9wOiAjRDBEMEQwIDFweCBzb2xpZDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDBweDtcbiAgcGFkZGluZzogMTBweDtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIGNvbG9yOiAjNjA2MDYwO1xuICBtYXJnaW46IDEwcHg7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbn1cblxuLndlbGxjb21lVGV4dCB7XG4gIHRvcDogMjUwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgd2lkdGg6IDEwMCU7XG4gIGNvbG9yOiAjZmZmO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/auth/auth.page.ts":
  /*!***********************************!*\
    !*** ./src/app/auth/auth.page.ts ***!
    \***********************************/

  /*! exports provided: AuthPage */

  /***/
  function srcAppAuthAuthPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthPage", function () {
      return AuthPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./auth.service */
    "./src/app/auth/auth.service.ts");
    /* harmony import */


    var _models_settings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../models/settings */
    "./src/app/models/settings.ts");

    var AuthPage = /*#__PURE__*/function () {
      function AuthPage(authService) {
        _classCallCheck(this, AuthPage);

        this.authService = authService;
      }

      _createClass(AuthPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ngAfterViewInit",
        value: function ngAfterViewInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.authService.userEmail = "suprabhatpaul@sdl.com";
          this.authService.userPassword = "Welcome@1234";
          this.authService.errorMessage = "";
          _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].token = "";
          _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].userEmail = "";
          _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].userName = "";
          _models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].userId = 0;
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {}
      }, {
        key: "onLogin",
        value: function onLogin() {
          this.authService.login(_models_settings__WEBPACK_IMPORTED_MODULE_3__["settings"].rootURL);
        }
      }]);

      return AuthPage;
    }();

    AuthPage.ctorParameters = function () {
      return [{
        type: _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]
      }];
    };

    AuthPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-auth',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./auth.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./auth.page.scss */
      "./src/app/auth/auth.page.scss"))["default"]]
    })], AuthPage);
    /***/
  }
}]);
//# sourceMappingURL=auth-auth-module-es5.js.map
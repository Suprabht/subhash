(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["changepassword-changepassword-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/changepassword/changepassword.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/changepassword/changepassword.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n \n  <ion-toolbar color=\"success\">\n    <ion-buttons>\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Change Password</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"ion-content\">\n    <ion-card class=\"card-center\" >\n      <ion-card-content>\n        <div class=\"changePasswordDiv\">\n            <ion-item>\n              <ion-label color=\"primary\" position =\"floating\">Old Password</ion-label>\n              <ion-input inputmode=\"password\" type=\"password\"required name=\"\" [(ngModel)]=\"this.changepasswordService.oldPassword\"></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-label color=\"primary\" position =\"floating\">New Password</ion-label>\n              <ion-input inputmode=\"password\" type=\"password\"required name=\"\" [(ngModel)]=\"this.changepasswordService.newPassword\"></ion-input>\n            </ion-item><br/>\n            <ion-text color=\"danger\">\n              {{this.changepasswordService.errorMessage}}\n            </ion-text>\n            <div class=\"changePasswordButton\">\n              <ion-button color=\"tertiary\" (click) =\"changePassword()\" >\n                <ion-icon name=\"reload-outline\"></ion-icon>&nbsp;&nbsp;Change Password\n              </ion-button>\n            </div>\n          \n          <br/><br/>\n        </div>\n      </ion-card-content>\n    </ion-card>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/changepassword/changepassword-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/changepassword/changepassword-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: ChangepasswordPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangepasswordPageRoutingModule", function() { return ChangepasswordPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _changepassword_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./changepassword.page */ "./src/app/changepassword/changepassword.page.ts");




const routes = [
    {
        path: '',
        component: _changepassword_page__WEBPACK_IMPORTED_MODULE_3__["ChangepasswordPage"]
    }
];
let ChangepasswordPageRoutingModule = class ChangepasswordPageRoutingModule {
};
ChangepasswordPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ChangepasswordPageRoutingModule);



/***/ }),

/***/ "./src/app/changepassword/changepassword.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/changepassword/changepassword.module.ts ***!
  \*********************************************************/
/*! exports provided: ChangepasswordPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangepasswordPageModule", function() { return ChangepasswordPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _changepassword_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./changepassword-routing.module */ "./src/app/changepassword/changepassword-routing.module.ts");
/* harmony import */ var _changepassword_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./changepassword.page */ "./src/app/changepassword/changepassword.page.ts");







let ChangepasswordPageModule = class ChangepasswordPageModule {
};
ChangepasswordPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _changepassword_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChangepasswordPageRoutingModule"]
        ],
        declarations: [_changepassword_page__WEBPACK_IMPORTED_MODULE_6__["ChangepasswordPage"]]
    })
], ChangepasswordPageModule);



/***/ }),

/***/ "./src/app/changepassword/changepassword.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/changepassword/changepassword.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ion-content {\n  display: block;\n  /* background-image: url(../../assets/loginBackground.jpg);\n   background-repeat: no-repeat;*/\n  width: 100%;\n  height: calc(100% - 60px);\n}\n.ion-content .card-center {\n  transform: translateX(-50%) translateY(-50%);\n  /*top: 45%;*/\n  top: 480px;\n  left: 50%;\n  position: absolute;\n}\n.ion-content .card-center .changePasswordDiv {\n  width: 450px;\n}\n.ion-content .card-center .changePasswordDiv .changePasswordButton {\n  float: right;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zdXByYWJoYXRwYXVsL0dpdC9Sb290L0lvbmljL1Zpc2l0b3JCb29rL0FwcC9kYWlseVZpc2l0b3JzL3NyYy9hcHAvY2hhbmdlcGFzc3dvcmQvY2hhbmdlcGFzc3dvcmQucGFnZS5zY3NzIiwic3JjL2FwcC9jaGFuZ2VwYXNzd29yZC9jaGFuZ2VwYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0VBQ0Q7aUNBQUE7RUFFQyxXQUFBO0VBQ0EseUJBQUE7QUNDSjtBREFJO0VBQ0ksNENBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtBQ0VSO0FERFE7RUFDSSxZQUFBO0FDR1o7QURGWTtFQUNJLFlBQUE7QUNJaEIiLCJmaWxlIjoic3JjL2FwcC9jaGFuZ2VwYXNzd29yZC9jaGFuZ2VwYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaW9uLWNvbnRlbnR7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAvKiBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi4vLi4vYXNzZXRzL2xvZ2luQmFja2dyb3VuZC5qcGcpO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7Ki9cbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDYwcHgpO1xuICAgIC5jYXJkLWNlbnRlcntcbiAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpIHRyYW5zbGF0ZVkoLTUwJSk7XG4gICAgICAgIC8qdG9wOiA0NSU7Ki9cbiAgICAgICAgdG9wOjQ4MHB4O1xuICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgLmNoYW5nZVBhc3N3b3JkRGl2e1xuICAgICAgICAgICAgd2lkdGg6IDQ1MHB4O1xuICAgICAgICAgICAgLmNoYW5nZVBhc3N3b3JkQnV0dG9ue1xuICAgICAgICAgICAgICAgIGZsb2F0OiByaWdodDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBcbn0iLCIuaW9uLWNvbnRlbnQge1xuICBkaXNwbGF5OiBibG9jaztcbiAgLyogYmFja2dyb3VuZC1pbWFnZTogdXJsKC4uLy4uL2Fzc2V0cy9sb2dpbkJhY2tncm91bmQuanBnKTtcbiAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7Ki9cbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogY2FsYygxMDAlIC0gNjBweCk7XG59XG4uaW9uLWNvbnRlbnQgLmNhcmQtY2VudGVyIHtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpIHRyYW5zbGF0ZVkoLTUwJSk7XG4gIC8qdG9wOiA0NSU7Ki9cbiAgdG9wOiA0ODBweDtcbiAgbGVmdDogNTAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG59XG4uaW9uLWNvbnRlbnQgLmNhcmQtY2VudGVyIC5jaGFuZ2VQYXNzd29yZERpdiB7XG4gIHdpZHRoOiA0NTBweDtcbn1cbi5pb24tY29udGVudCAuY2FyZC1jZW50ZXIgLmNoYW5nZVBhc3N3b3JkRGl2IC5jaGFuZ2VQYXNzd29yZEJ1dHRvbiB7XG4gIGZsb2F0OiByaWdodDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/changepassword/changepassword.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/changepassword/changepassword.page.ts ***!
  \*******************************************************/
/*! exports provided: ChangepasswordPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangepasswordPage", function() { return ChangepasswordPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _models_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/settings */ "./src/app/models/settings.ts");
/* harmony import */ var _changepassword_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./changepassword.service */ "./src/app/changepassword/changepassword.service.ts");




let ChangepasswordPage = class ChangepasswordPage {
    constructor(changepasswordService) {
        this.changepasswordService = changepasswordService;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.changepasswordService.email = _models_settings__WEBPACK_IMPORTED_MODULE_2__["settings"].userEmail;
        this.changepasswordService.oldPassword = "";
        this.changepasswordService.newPassword = "";
        this.changepasswordService.errorMessage = "";
    }
    ionViewDidEnter() { }
    changePassword() {
        this.changepasswordService.changePassword(_models_settings__WEBPACK_IMPORTED_MODULE_2__["settings"].rootURL);
    }
};
ChangepasswordPage.ctorParameters = () => [
    { type: _changepassword_service__WEBPACK_IMPORTED_MODULE_3__["ChangepasswordService"] }
];
ChangepasswordPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-changepassword',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./changepassword.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/changepassword/changepassword.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./changepassword.page.scss */ "./src/app/changepassword/changepassword.page.scss")).default]
    })
], ChangepasswordPage);



/***/ }),

/***/ "./src/app/changepassword/changepassword.service.ts":
/*!**********************************************************!*\
  !*** ./src/app/changepassword/changepassword.service.ts ***!
  \**********************************************************/
/*! exports provided: ChangepasswordService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangepasswordService", function() { return ChangepasswordService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");




let ChangepasswordService = class ChangepasswordService {
    constructor(http, router) {
        this.http = http;
        this.router = router;
        this.email = "";
        this.oldPassword = "";
        this.newPassword = "";
        this.errorMessage = "";
    }
    changePassword(rootURL) {
        if ((this.oldPassword != "") && (this.newPassword != "")) {
            if (this.validatePassword(this.newPassword)) {
                var usermodel = {
                    "email": this.email,
                    "oldPassword": this.oldPassword,
                    "newPassword": this.newPassword
                };
                this.http.post(rootURL + '/Authentication/ChangePassword', usermodel).subscribe((resp) => {
                    if (resp.result == "Error") {
                        this.errorMessage = resp.text;
                    }
                    else {
                        this.router.navigateByUrl('/auth');
                    }
                }, (error) => {
                    this.errorMessage = "Password can not be changed!";
                });
            }
            else {
                this.errorMessage = "Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character";
            }
        }
        else {
            this.errorMessage = "Please enter passwords properly!";
        }
    }
    validatePassword(password) {
        //Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character
        if (/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password)) {
            return (true);
        }
        return (false);
    }
};
ChangepasswordService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
ChangepasswordService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], ChangepasswordService);



/***/ })

}]);
//# sourceMappingURL=changepassword-changepassword-module-es2015.js.map